/**
 * Created by liusome on 2016/11/07.
 */


//列表数据
var jsondata = {
    "data": {
        "type_list": [
            {
                "book_list": [
                    {
                        "author": "王应麟",
                        "available_play": "1",
                        "book_id": "65",
                        "book_name": "三字经（一）",
                        "book_pic_list": {
                            "large": "http://www.ivydad.com/ivydad/image/book/65/%E4%B8%89%E5%AD%97%E7%BB%8F_1242x840_2.jpg",
                            "middle": "http://www.ivydad.com/ivydad/image/book/65/%E4%B8%89%E5%AD%97%E7%BB%8F_312x234_2.jpg",
                            "small": "http://www.ivydad.com/ivydad/image/book/65/%E4%B8%89%E5%AD%97%E7%BB%8F_210x180_3.jpg"
                        },
                        "is_free": "1"
                    },
                    {
                        "author": "周兴嗣",
                        "available_play": "1",
                        "book_id": "66",
                        "book_name": "千字文（一）",
                        "book_pic_list": {
                            "large": "http://www.ivydad.com/ivydad/image/book/66/%E5%8D%83%E5%AD%97%E6%96%87_1242x840_2.jpg",
                            "middle": "http://www.ivydad.com/ivydad/image/book/66/%E5%8D%83%E5%AD%97%E6%96%87_312x234_2.jpg",
                            "small": "http://www.ivydad.com/ivydad/image/book/66/%E5%8D%83%E5%AD%97%E6%96%87_210x180_3.jpg"
                        },
                        "is_free": "1"
                    },
                    {
                        "author": "车万育",
                        "available_play": "1",
                        "book_id": "83",
                        "book_name": "东",
                        "book_pic_list": {
                            "large": "http://www.ivydad.com/ivydad/image/book/83/%E4%B8%9C_1242x840_1.jpg",
                            "middle": "http://www.ivydad.com/ivydad/image/book/83/%E4%B8%9C_312x234_1.jpg",
                            "small": "http://www.ivydad.com/ivydad/image/book/83/%E4%B8%9C_210x180_1.jpg"
                        },
                        "is_free": "1"
                    }
                ],
                "cat_id": "02",
                "cat_name": "国学",
                "if_more": "1",
                "type_id": "13",
                "type_name": "国学"
            },
            {
                "book_list": [
                    {
                        "author": "Twin Sisters",
                        "available_play": "1",
                        "book_id": "202",
                        "book_name": "The Muffin Man",
                        "book_pic_list": {
                            "large": "http://www.ivydad.com/ivydad/image/book/202/The_Muffin_Man_1242x840_1.jpg",
                            "middle": "http://www.ivydad.com/ivydad/image/book/202/The_Muffin_Man_312x234_1.jpg",
                            "small": "http://www.ivydad.com/ivydad/image/book/202/The_Muffin_Man_210x180_1.jpg"
                        },
                        "is_free": "1"
                    },
                    {
                        "author": "Twin Sisters",
                        "available_play": "1",
                        "book_id": "201",
                        "book_name": "Row Row Row Your Boat",
                        "book_pic_list": {
                            "large": "http://www.ivydad.com/ivydad/image/book/201/Row_Row_Row_Your_Boat_1242x840_1.jpg",
                            "middle": "http://www.ivydad.com/ivydad/image/book/201/Row_Row_Row_Your_Boat_312x234_1.jpg",
                            "small": "http://www.ivydad.com/ivydad/image/book/201/Row_Row_Row_Your_Boat_210x180_1.jpg"
                        },
                        "is_free": "1"
                    },
                    {
                        "author": "Twin Sisters",
                        "available_play": "1",
                        "book_id": "200",
                        "book_name": "Mary Had a Little Lamb",
                        "book_pic_list": {
                            "large": "http://www.ivydad.com/ivydad/image/book/200/Mary_Had_a_Little_Lamb_1242x840_1.jpg",
                            "middle": "http://www.ivydad.com/ivydad/image/book/200/Mary_Had_a_Little_Lamb_312x234_1.jpg",
                            "small": "http://www.ivydad.com/ivydad/image/book/200/Mary_Had_a_Little_Lamb_210x180_1.jpg"
                        },
                        "is_free": "1"
                    }
                ],
                "cat_id": "-03",
                "cat_name": "最新音频",
                "if_more": "1",
                "type_id": "-04",
                "type_name": "最新音频"
            },
            {
                "book_list": [
                    {
                        "author": "Mem Fox/Jane Dyer",
                        "available_play": "1",
                        "book_id": "12",
                        "book_name": "Time For Bed",
                        "book_pic_list": {
                            "large": "http://www.ivydad.com/ivydad/image/book/12/Time%20for%20Bed%20%28Mem%20Fox%29%20%5BBoard%5D_1242x840_2.jpg",
                            "middle": "http://www.ivydad.com/ivydad/image/book/12/Time%20for%20Bed%20%28Mem%20Fox%29%20%5BBoard%5D_312x234_2.jpg",
                            "small": "http://www.ivydad.com/ivydad/image/book/12/Time_For_Bed_210x180_3.jpg"
                        },
                        "is_free": "1"
                    },
                    {
                        "author": "Margaret Wise Brown/Clement Hurd",
                        "available_play": "1",
                        "book_id": "9",
                        "book_name": "Goodnight Moon",
                        "book_pic_list": {
                            "large": "http://www.ivydad.com/ivydad/image/book/9/Goodnight%2C%20Moon%20%5BPaperback%5D_1242x840_1.jpg",
                            "middle": "http://www.ivydad.com/ivydad/image/book/9/Goodnight%2C%20Moon%20%5BPaperback%5D_312x234_1.jpg",
                            "small": "http://www.ivydad.com/ivydad/image/book/9/Goodnight_Moon_210x180_2.jpg"
                        },
                        "is_free": "1"
                    }
                ],
                "cat_id": "01",
                "cat_name": "英文绘本",
                "if_more": "1",
                "type_id": "1",
                "type_name": "英文经典-1岁+"
            },
            {
                "book_list": [
                    {
                        "author": "Audrey Wood/Don Wood",
                        "available_play": "1",
                        "book_id": "35",
                        "book_name": "Quick as a Cricket",
                        "book_pic_list": {
                            "large": "http://www.ivydad.com/ivydad/image/book/35/Quick_as_a_Cricket_1242x840_1.jpg",
                            "middle": "http://www.ivydad.com/ivydad/image/book/35/Quick_as_a_Cricket_312x234_1.jpg",
                            "small": "http://www.ivydad.com/ivydad/image/book/35/Quick_as_a_Cricket_210x180_1.jpg"
                        },
                        "is_free": "1"
                    },
                    {
                        "author": "Audrey Wood / Don Wood",
                        "available_play": "1",
                        "book_id": "47",
                        "book_name": "The Napping House",
                        "book_pic_list": {
                            "large": "http://www.ivydad.com/ivydad/image/book/47/_THE_NAPPING_HOUSE__1242x840_1.jpg",
                            "middle": "http://www.ivydad.com/ivydad/image/book/47/_THE_NAPPING_HOUSE__312x234_1.jpg",
                            "small": "http://www.ivydad.com/ivydad/image/book/47/_THE_NAPPING_HOUSE__210x180_1.jpg"
                        },
                        "is_free": "1"
                    }
                ],
                "cat_id": "01",
                "cat_name": "英文绘本",
                "if_more": "1",
                "type_id": "6",
                "type_name": "英文经典-2岁+"
            },
            {
                "book_list": [
                    {
                        "author": "妮娜·菲利佩克/杰奎琳·伊斯特",
                        "available_play": "1",
                        "book_id": "68",
                        "book_name": "Jack and the Beanstalk",
                        "book_pic_list": {
                            "large": "http://www.ivydad.com/ivydad/image/book/68/Jack_and_the_Beanstalk_1242x840_1.jpg",
                            "middle": "http://www.ivydad.com/ivydad/image/book/68/Jack_and_the_Beanstalk_312x234_1.jpg",
                            "small": "http://www.ivydad.com/ivydad/image/book/68/Jack_and_the_Beanstalk_210x180_1.jpg"
                        },
                        "is_free": "1"
                    },
                    {
                        "author": "妮娜·菲利佩克/凯瑟琳·柯克兰",
                        "available_play": "1",
                        "book_id": "75",
                        "book_name": "Rapunzel",
                        "book_pic_list": {
                            "large": "http://www.ivydad.com/ivydad/image/book/75/Rapunzel_1242x840_1.jpg",
                            "middle": "http://www.ivydad.com/ivydad/image/book/75/Rapunzel_312x234_1.jpg",
                            "small": "http://www.ivydad.com/ivydad/image/book/75/Rapunzel_210x180_1.jpg"
                        },
                        "is_free": "1"
                    }
                ],
                "cat_id": "01",
                "cat_name": "英文绘本",
                "if_more": "1",
                "type_id": "12",
                "type_name": "童话"
            }
        ]
    }
};
//音频数据
var audiojsondata = {
    "data": {
        "book_list": [
            {
                "audio_list": [
                    {
                        "audio_length": "136",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/9/Goodnight_Moon_americanLyric_6.lrc",
                        "audio_lyric_version": "6",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「Goodnight Moon」",
                        "audio_type": "american",
                        "audio_type_name": "美音",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/9/Goodnight%2C%20Moon_americanVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    },
                    {
                        "audio_length": "117",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/9/Goodnight_Moon_englishLyric_6.lrc",
                        "audio_lyric_version": "6",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「Goodnight Moon」",
                        "audio_type": "english",
                        "audio_type_name": "英音",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/9/Goodnight%2C%20Moon%20%5BPaperback%5D_englishVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    },
                    {
                        "audio_length": "176",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/9/Goodnight_Moon_musicLyric_3.lrc",
                        "audio_lyric_version": "3",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「Goodnight Moon」",
                        "audio_type": "music",
                        "audio_type_name": "歌曲",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/9/Goodnight%2C_Moon_musicVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    }
                ],
                "author": "Margaret Wise Brown/Clement Hurd",
                "available_play": "1",
                "book_id": "9",
                "book_name": "Goodnight Moon",
                "book_pic_list": {
                    "large": "http://www.ivydad.com/ivydad/image/book/9/Goodnight%2C%20Moon%20%5BPaperback%5D_1242x840_1.jpg",
                    "middle": "http://www.ivydad.com/ivydad/image/book/9/Goodnight%2C%20Moon%20%5BPaperback%5D_312x234_1.jpg",
                    "small": "http://www.ivydad.com/ivydad/image/book/9/Goodnight_Moon_210x180_2.jpg"
                },
                "cat_id": "01",
                "cat_name": "英文绘本",
                "desc": "一只小兔子准备要上床睡觉，它向周围每一样东西道晚安。随着夜色变深，房间里的光线也逐渐昏暗。最后，万籁俱寂，小兔安心地睡着了。",
                "is_free": "1",
                "recommend": "这是一个柔美的睡前故事，基本没有故事情节，只是小兔子在睡觉前向身边每一件熟悉的事物说晚安。而这些精心选择的事物，和不断重复的“Good Night”，让整个绘本的文字变成一首小诗，非常有节奏感和韵律感，很适合做为一岁多孩子的哄睡绘本。",
                "share_url": "http://exploiter.ivydad.com:80/book/share/9",
                "stage_id": "1",
                "stage_name": "英文经典",
                "story": "1945年的一个清晨，一大早起床的Margaret Wise Brown一口气就把《Goodnight，Moon》的文字写完。她曾经说过她写的许多故事都是来自于她的梦，《Goodnight， Moon》就是其中之一。并且自从1947年该书问世以来，超过半个世纪，在全世界各种版本加在一起就已经卖出了一千万册，被纽约公共图书馆选入「本世纪具有影响力的经典书籍之一」。有人说，在美国判断妈妈是不是合格，就看她会不会背《Goodnight， Moon》，因为一个好妈妈一定是每天晚上给孩子读这本书读到都会背。",
                "tags": "【特别提示】英文绘本音频为随书赠送，《彩虹鱼系列》和《鼹鼠的故事》音频为对应的团购书籍赠送，请到“常春藤爸爸”公众号的有赞小店获取。\n\n国学音频正在内测，目前只开放了3首免费完整版，九月份可通过全新会员制度获得相应播放权限。",
                "type_id": "1",
                "type_name": "英文经典-1岁+"
            },
            {
                "audio_list": [
                    {
                        "audio_length": "138",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/12/Time_For_Bed_americanLyric_11.lrc",
                        "audio_lyric_version": "11",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「Time For Bed」",
                        "audio_type": "american",
                        "audio_type_name": "美音",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/12/Time%20for%20Bed_americanVoice_4.mp3",
                        "audio_version": "4",
                        "is_default": ""
                    },
                    {
                        "audio_length": "140",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/12/Time_For_Bed_englishLyric_10.lrc",
                        "audio_lyric_version": "10",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「Time For Bed」",
                        "audio_type": "english",
                        "audio_type_name": "英音",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/12/Time%20for%20Bed%20%28Mem%20Fox%29%20%5BBoard%5D_englishVoice_3.mp3",
                        "audio_version": "3",
                        "is_default": ""
                    },
                    {
                        "audio_length": "204",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/12/Time_For_Bed_musicLyric_6.lrc",
                        "audio_lyric_version": "6",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「Time For Bed」",
                        "audio_type": "music",
                        "audio_type_name": "歌曲",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/12/Time_For_Bed_musicVoice_3.mp3",
                        "audio_version": "3",
                        "is_default": ""
                    }
                ],
                "author": "Mem Fox/Jane Dyer",
                "available_play": "1",
                "book_id": "12",
                "book_name": "Time For Bed",
                "book_pic_list": {
                    "large": "http://www.ivydad.com/ivydad/image/book/12/Time%20for%20Bed%20%28Mem%20Fox%29%20%5BBoard%5D_1242x840_2.jpg",
                    "middle": "http://www.ivydad.com/ivydad/image/book/12/Time%20for%20Bed%20%28Mem%20Fox%29%20%5BBoard%5D_312x234_2.jpg",
                    "small": "http://www.ivydad.com/ivydad/image/book/12/Time_For_Bed_210x180_3.jpg"
                },
                "cat_id": "01",
                "cat_name": "英文绘本",
                "desc": "夜幕低垂，喧嚣散去，是时候睡觉了，宝宝。幼儿时期，每个夜晚父母都会在孩子床边低声吟唱一首歌谣，或者讲上一个故事，只愿宝宝香甜入睡，原来动物们哄自己的宝宝睡觉也有自己的招数：天鹅看看星空、猫咪互相依偎、奶牛聊聊今天的趣事、马儿倾诉秘密……",
                "is_free": "1",
                "recommend": "这是一本非常温馨的充满韵律感的哄睡绘本。反复出现的句式，读来朗朗上口，也起到助眠的作用。另外，可以通过这个本书学习一些动物在“婴儿期”的叫法，比如baby horse叫foal，baby cow叫calf。",
                "share_url": "http://exploiter.ivydad.com:80/book/share/12",
                "stage_id": "1",
                "stage_name": "英文经典",
                "story": "梅·福克斯（Mem Fox），澳大利亚著名亲子阅读专家，畅销书作家。1946年出生于墨尔本，曾任教阿得雷德市富林德大学（Flinders University）讲授读写能力研究，也是著名国际读写能力顾问，经常往来世界各国推广“为孩子阅读”的理念。现为专职作家，居住南澳大利亚阿得雷德市。作品涵盖童书及成人书籍，广受大人、小孩喜爱。",
                "tags": "【特别提示】英文绘本音频为随书赠送，《彩虹鱼系列》和《鼹鼠的故事》音频为对应的团购书籍赠送，请到“常春藤爸爸”公众号的有赞小店获取。\n\n国学音频正在内测，目前只开放了3首免费完整版，九月份可通过全新会员制度获得相应播放权限。",
                "type_id": "1",
                "type_name": "英文经典-1岁+"
            },
            {
                "audio_list": [
                    {
                        "audio_length": "139",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/35/Quick_as_a_Cricket_americanLyric_1.lrc",
                        "audio_lyric_version": "1",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「Quick as a Cricket」",
                        "audio_type": "american",
                        "audio_type_name": "美音",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/35/Quick_as_a_Cricket_americanVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    },
                    {
                        "audio_length": "107",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/35/Quick_as_a_Cricket_englishLyric_1.lrc",
                        "audio_lyric_version": "1",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「Quick as a Cricket」",
                        "audio_type": "english",
                        "audio_type_name": "英音",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/35/Quick_as_a_Cricket_englishVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    },
                    {
                        "audio_length": "131",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/35/Quick_as_a_Cricket_musicLyric_5.lrc",
                        "audio_lyric_version": "5",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「Quick as a Cricket」",
                        "audio_type": "music",
                        "audio_type_name": "歌曲",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/35/Quick_as_a_Cricket_musicVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    }
                ],
                "author": "Audrey Wood/Don Wood",
                "available_play": "1",
                "book_id": "35",
                "book_name": "Quick as a Cricket",
                "book_pic_list": {
                    "large": "http://www.ivydad.com/ivydad/image/book/35/Quick_as_a_Cricket_1242x840_1.jpg",
                    "middle": "http://www.ivydad.com/ivydad/image/book/35/Quick_as_a_Cricket_312x234_1.jpg",
                    "small": "http://www.ivydad.com/ivydad/image/book/35/Quick_as_a_Cricket_210x180_1.jpg"
                },
                "cat_id": "01",
                "cat_name": "英文绘本",
                "desc": "我像蟋蟀一样快的同时，又像蜗牛一样慢；我像蚂蚁一样小的同时，又像鲸鱼一样大……小男孩借助周遭熟悉的动物来传达自己的心情，在这场感受之旅当中更加认识自己。",
                "is_free": "1",
                "recommend": "孩子在成长过程中，如何来认识自己？尤其是情绪和感受，诸如此类抽象的感觉问题，作者给了一个绝妙的方向：通过孩子对动物的认知和感受，类比的方式让孩子们更加认识自己。同时句式的一致性和形容词的对立性也使本书极具韵律和趣味。是孩子认识自己、学习形容词的最佳读物。",
                "share_url": "http://exploiter.ivydad.com:80/book/share/35",
                "stage_id": "1",
                "stage_name": "英文经典",
                "story": "奥黛莉．伍德(Audrey Wood)生于阿肯色州小岩城的艺术世家，毕业于阿肯色艺术中心。唐．伍德(Don Wood)生于加州中部的农场，毕业于加州大学圣塔芭芭拉分校，并于1967年从加州工艺学院取得艺术硕士学位后，和奥黛莉结婚。1981年，这对夫妇首次合作图画书，由唐．伍德为奥黛莉．伍德写的故事配上插图，之后，他们陆续完成了好几本精采的图画书，包括《谁要吃草莓》，以及曾经获得1984年纽约时报年度最佳儿童插画奖的《打瞌睡的房子》和得到1986年凯迪克荣誉奖的《澡缸里的国王》。除了夫妻合作外，奥黛莉伍德也有自写自画的图画书作品问世。",
                "tags": "【特别提示】英文绘本音频为随书赠送，《彩虹鱼系列》和《鼹鼠的故事》音频为对应的团购书籍赠送，请到“常春藤爸爸”公众号的有赞小店获取。\n\n国学音频正在内测，目前只开放了3首免费完整版，九月份可通过全新会员制度获得相应播放权限。",
                "type_id": "6",
                "type_name": "英文经典-2岁+"
            },
            {
                "audio_list": [
                    {
                        "audio_length": "179",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/47/_The_Napping_House__americanLyric_2.lrc",
                        "audio_lyric_version": "2",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「The Napping House」",
                        "audio_type": "american",
                        "audio_type_name": "美音",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/47/_The_Napping_House__americanVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    },
                    {
                        "audio_length": "201",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/47/_The_Napping_House__englishLyric_1.lrc",
                        "audio_lyric_version": "1",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「The Napping House」",
                        "audio_type": "english",
                        "audio_type_name": "英音",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/47/_The_Napping_House__englishVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    },
                    {
                        "audio_length": "286",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/47/_The_Napping_House__musicLyric_1.lrc",
                        "audio_lyric_version": "1",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「The Napping House」",
                        "audio_type": "music",
                        "audio_type_name": "歌曲",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/47/_The_Napping_House__musicVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    }
                ],
                "author": "Audrey Wood / Don Wood",
                "available_play": "1",
                "book_id": "47",
                "book_name": "The Napping House",
                "book_pic_list": {
                    "large": "http://www.ivydad.com/ivydad/image/book/47/_THE_NAPPING_HOUSE__1242x840_1.jpg",
                    "middle": "http://www.ivydad.com/ivydad/image/book/47/_THE_NAPPING_HOUSE__312x234_1.jpg",
                    "small": "http://www.ivydad.com/ivydad/image/book/47/_THE_NAPPING_HOUSE__210x180_1.jpg"
                },
                "cat_id": "01",
                "cat_name": "英文绘本",
                "desc": "有一栋打瞌睡的房子，住在里面的人都在睡觉，睡得很香很沉。老婆婆睡在大床睡觉，小孩子睡在婆婆身上，狗狗睡在小孩身上…… 突然，一直老鼠出现了，猫、狗、小孩都被吓得飞了起来，老婆婆还压垮了床，最后大家都醒了，打瞌睡的房子里现在没有人在打瞌睡了。",
                "is_free": "1",
                "recommend": "作者以重复的句型和叠句的结构，使文字产生了节奏和旋律，读起来朗朗上口。书中的角色塑造鲜活，画面描绘细腻，色彩运用独到，加上逐步变化的视点让整个故事充满戏剧感和幽默感。本书不失Wood夫妇作品一贯的风格。本书1984年荣获美国图书馆协会杰出童书奖、纽约时报最佳儿童图画书奖、年美国童书作家协会金风筝奖、美国全国英语教师协会选书，入选纽约公共图书馆“每个人都应该知道的100本图画书”。",
                "share_url": "http://exploiter.ivydad.com:80/book/share/47",
                "stage_id": "1",
                "stage_name": "英文经典",
                "story": "Don Wood和Audrey Wood是美国童书界很受欢迎的一对夫妻档。1969年他们相遇并且在这一年那就举办了婚礼，人生结伴的旅途中为孩子们创作了许多精彩的图画书。Audrey出生在文艺世家，而Don则从小生活在农庄里。长子 Bruce Robert 的出生为 Audrey Wood 和 Don Wood 带来许多的快乐，也勾起 Audrey Wood 对童年的回忆，她开始认真地创作童书，而丈夫 Don Wood因每天为两岁大的儿子念床边故事，而爱上儿童文学，开始从事绘本插画工作，并且乐此不疲。他们搭档合作的作品不仅故事精彩、文字优美，插画风格更是精彩多变、独树一帜！深受广大读者喜爱。",
                "tags": "【特别提示】英文绘本音频为随书赠送，《彩虹鱼系列》和《鼹鼠的故事》音频为对应的团购书籍赠送，请到“常春藤爸爸”公众号的有赞小店获取。\n\n国学音频正在内测，目前只开放了3首免费完整版，九月份可通过全新会员制度获得相应播放权限。",
                "type_id": "6",
                "type_name": "英文经典-2岁+"
            },
            {
                "audio_list": [
                    {
                        "audio_length": "52",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/57/Roly_Poly_Pop-up%EF%BC%9AOcean_americanLyric_1.lrc",
                        "audio_lyric_version": "1",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「Ocean」",
                        "audio_type": "american",
                        "audio_type_name": "美音",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/57/Ocean_americanVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    }
                ],
                "author": "Kees Moerbeek",
                "available_play": "1",
                "book_id": "57",
                "book_name": "Ocean",
                "book_pic_list": {
                    "large": "http://www.ivydad.com/ivydad/image/book/57/Ocean_1242x840_2.jpg",
                    "middle": "http://www.ivydad.com/ivydad/image/book/57/Ocean_312x234_2.jpg",
                    "small": "http://www.ivydad.com/ivydad/image/book/57/Ocean_210x180_4.jpg"
                },
                "cat_id": "01",
                "cat_name": "英文绘本",
                "desc": "海洋里都发生了什么呢？快打开立体魔方书看看！",
                "is_free": "1",
                "recommend": "ROLY POLY系列的立体化设计大大加强孩子和读本的互动，故事的每一主要场景都用立体方式呈现，孩子犹如在看舞台剧一般，让那些谈“读”色变的孩子也爱上阅读！",
                "share_url": "http://exploiter.ivydad.com:80/book/share/57",
                "stage_id": "8",
                "stage_name": "英文团购",
                "story": "ROLY POLY系列立体魔方书共有8种，分成两个套装（认知类4种，适合1-4岁的孩子；故事类4种，适合2.5-5岁的孩子 – 故事类的文字较多，适合英文启蒙过一段时间的孩子）。\n认知类的4种是：Ocean (海洋)，Space (太空)，Jungle (丛林)，和Numbers (数字)。",
                "tags": "【特别提示】英文绘本音频为随书赠送，《彩虹鱼系列》和《鼹鼠的故事》音频为对应的团购书籍赠送，请到“常春藤爸爸”公众号的有赞小店获取。\n\n国学音频正在内测，目前只开放了3首免费完整版，九月份可通过全新会员制度获得相应播放权限。",
                "type_id": "8",
                "type_name": "立体书"
            },
            {
                "audio_list": [
                    {
                        "audio_length": "221",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/62/Roly_Poly_Pop-up%EF%BC%9AThree_Little_Pig_americanLyric_1.lrc",
                        "audio_lyric_version": "1",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「The Three Little Pigs」",
                        "audio_type": "american",
                        "audio_type_name": "美音",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/62/Roly_Poly_Pop-up%EF%BC%9AThree_Little_Pig_americanVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    }
                ],
                "author": "Kees Moerbeek",
                "available_play": "1",
                "book_id": "62",
                "book_name": "The Three Little Pigs",
                "book_pic_list": {
                    "large": "http://www.ivydad.com/ivydad/image/book/62/The_Three_Little_Pigs_1242x840_2.jpg",
                    "middle": "http://www.ivydad.com/ivydad/image/book/62/The_Three_Little_Pigs_312x234_2.jpg",
                    "small": "http://www.ivydad.com/ivydad/image/book/62/The_Three_Little_Pigs_210x180_3.jpg"
                },
                "cat_id": "01",
                "cat_name": "英文绘本",
                "desc": "三只小猪长得太快，被猪妈妈要求他们自己建房子住，可是要小心大坏狼……三只小猪的房子修得究竟如何？大坏狼来了吗？",
                "is_free": "1",
                "recommend": "ROLY POLY系列的立体化设计大大加强孩子和读本的互动，故事的每一主要场景都用立体方式呈现，孩子犹如在看舞台剧一般，让那些谈“读”色变的孩子也爱上阅读！",
                "share_url": "http://exploiter.ivydad.com:80/book/share/62",
                "stage_id": "8",
                "stage_name": "英文团购",
                "story": "ROLY POLY系列立体魔方书共有8种，分成两个套装（认知类4种，适合1-4岁的孩子；故事类4种，适合2.5-5岁的孩子 – 故事类的文字较多，适合英文启蒙过一段时间的孩子）。\n故事类的4种是：Three Little Pigs (三只小猪)，Cinderella (灰姑娘)，Goldilocks (金发女孩)和Nursery Rhymes(童谣)。",
                "tags": "【特别提示】英文绘本音频为随书赠送，《彩虹鱼系列》和《鼹鼠的故事》音频为对应的团购书籍赠送，请到“常春藤爸爸”公众号的有赞小店获取。\n\n国学音频正在内测，目前只开放了3首免费完整版，九月份可通过全新会员制度获得相应播放权限。",
                "type_id": "8",
                "type_name": "立体书"
            },
            {
                "audio_list": [
                    {
                        "audio_length": "421",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/68/Jack_and_the_Beanstalk_americanLyric_2.lrc",
                        "audio_lyric_version": "2",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「Jack and the Beanstalk」",
                        "audio_type": "american",
                        "audio_type_name": "美音",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/68/Jack_and_the_Beanstalk_americanVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    },
                    {
                        "audio_length": "476",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/68/Jack_and_the_Beanstalk_englishLyric_2.lrc",
                        "audio_lyric_version": "2",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「Jack and the Beanstalk」",
                        "audio_type": "english",
                        "audio_type_name": "英音",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/68/Jack_and_the_Beanstalk_englishVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    }
                ],
                "author": "妮娜·菲利佩克/杰奎琳·伊斯特",
                "available_play": "1",
                "book_id": "68",
                "book_name": "Jack and the Beanstalk",
                "book_pic_list": {
                    "large": "http://www.ivydad.com/ivydad/image/book/68/Jack_and_the_Beanstalk_1242x840_1.jpg",
                    "middle": "http://www.ivydad.com/ivydad/image/book/68/Jack_and_the_Beanstalk_312x234_1.jpg",
                    "small": "http://www.ivydad.com/ivydad/image/book/68/Jack_and_the_Beanstalk_210x180_1.jpg"
                },
                "cat_id": "01",
                "cat_name": "英文绘本",
                "desc": "“等月亮出来，我们就能跟着鹅卵石回家了！”兄妹俩被继母骗到森林里抛弃，聪明的哥哥跟着来时扔在路上的鹅卵石回了家。第二天，小鸟吃掉了指路的面包屑，他们在森林里迷了路。兄妹俩跟着小鸟来到巫婆的糖果屋，成了巫婆的大餐……",
                "is_free": "1",
                "recommend": "文字优美地道。这套绘本是是由英国教科书编辑妮娜·菲利佩克编写，她对儿童心理把握透彻、对语言运用严谨精湛。细读本书英文，可以感觉到处处朗朗上口、富有节奏，读起来富有韵味。另外，她对童话进行了一些改编，更贴近孩子们的生活和语言、行为习惯，读起来更亲切。著名插画师凯瑟琳·柯克兰、杰奎琳·伊斯特、布鲁诺·梅尔兹分别对不同的故事配上风格活泼、色彩明丽的插图，进行了创新，增加了很多小配角，使得经典焕发生机，更加栩栩如生。",
                "share_url": "http://exploiter.ivydad.com:80/book/share/68",
                "stage_id": "8",
                "stage_name": "英文团购",
                "story": "妮娜·菲力佩克（Nina Filipek），英国教科书编辑，自由职业作家，有名的讲故事的人。其讲述的故事情节丰满，语言浅明而充满奇幻色彩。喜欢运用重复的高潮语言与细节的改变，来吸引幼儿注意力，帮助发展幼儿的语言能力。目前她专注于童书、科教书的创作与编辑。",
                "tags": "【特别提示】英文绘本音频为随书赠送，《彩虹鱼系列》和《鼹鼠的故事》音频为对应的团购书籍赠送，请到“常春藤爸爸”公众号的有赞小店获取。\n\n国学音频正在内测，目前只开放了3首免费完整版，九月份可通过全新会员制度获得相应播放权限。",
                "type_id": "12",
                "type_name": "童话"
            },
            {
                "audio_list": [
                    {
                        "audio_length": "401",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/75/Rapunzel_americanLyric_1.lrc",
                        "audio_lyric_version": "1",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「Rapunzel」",
                        "audio_type": "american",
                        "audio_type_name": "美音",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/75/Rapunzel_americanVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    },
                    {
                        "audio_length": "437",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/75/Rapunzel_englishLyric_1.lrc",
                        "audio_lyric_version": "1",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「Rapunzel」",
                        "audio_type": "english",
                        "audio_type_name": "英音",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/75/Rapunzel_englishVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    }
                ],
                "author": "妮娜·菲利佩克/凯瑟琳·柯克兰",
                "available_play": "1",
                "book_id": "75",
                "book_name": "Rapunzel",
                "book_pic_list": {
                    "large": "http://www.ivydad.com/ivydad/image/book/75/Rapunzel_1242x840_1.jpg",
                    "middle": "http://www.ivydad.com/ivydad/image/book/75/Rapunzel_312x234_1.jpg",
                    "small": "http://www.ivydad.com/ivydad/image/book/75/Rapunzel_210x180_1.jpg"
                },
                "cat_id": "01",
                "cat_name": "英文绘本",
                "desc": "“长发公主！长发公主！快把头发放下来！”女巫把长发公主锁在一座高塔里，每天拽着她的辫子爬上爬下。一位英俊的王子来到森林，寻着美妙的歌声见到了长发公主，每天都去探望她。他们不知道，邪恶的女巫已经发现了这个秘密……",
                "is_free": "1",
                "recommend": "文字优美地道。这套绘本是是由英国教科书编辑妮娜·菲利佩克编写，她对儿童心理把握透彻、对语言运用严谨精湛。细读本书英文，可以感觉到处处朗朗上口、富有节奏，读起来富有韵味。另外，她对童话进行了一些改编，更贴近孩子们的生活和语言、行为习惯，读起来更亲切。著名插画师凯瑟琳·柯克兰、杰奎琳·伊斯特、布鲁诺·梅尔兹分别对不同的故事配上风格活泼、色彩明丽的插图，进行了创新，增加了很多小配角，使得经典焕发生机，更加栩栩如生。",
                "share_url": "http://exploiter.ivydad.com:80/book/share/75",
                "stage_id": "8",
                "stage_name": "英文团购",
                "story": "妮娜·菲力佩克（Nina Filipek），英国教科书编辑，自由职业作家，有名的讲故事的人。其讲述的故事情节丰满，语言浅明而充满奇幻色彩。喜欢运用重复的高潮语言与细节的改变，来吸引幼儿注意力，帮助发展幼儿的语言能力。目前她专注于童书、科教书的创作与编辑。",
                "tags": "【特别提示】英文绘本音频为随书赠送，《彩虹鱼系列》和《鼹鼠的故事》音频为对应的团购书籍赠送，请到“常春藤爸爸”公众号的有赞小店获取。\n\n国学音频正在内测，目前只开放了3首免费完整版，九月份可通过全新会员制度获得相应播放权限。",
                "type_id": "12",
                "type_name": "童话"
            },
            {
                "audio_list": [
                    {
                        "audio_length": "176",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/131/Dentist_Trip_americanLyric_5.lrc",
                        "audio_lyric_version": "5",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「Dentist Trip」",
                        "audio_type": "american",
                        "audio_type_name": "美音",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/131/Dentist_Trip_americanVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    },
                    {
                        "audio_length": "194",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/131/Dentist_Trip_englishLyric_5.lrc",
                        "audio_lyric_version": "5",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「Dentist Trip」",
                        "audio_type": "english",
                        "audio_type_name": "英音",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/131/Dentist_Trip_englishVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    }
                ],
                "author": "Neville Astley / Mark Baker",
                "available_play": "1",
                "book_id": "131",
                "book_name": "Dentist Trip",
                "book_pic_list": {
                    "large": "http://www.ivydad.com/ivydad/image/book/131/Dentist_Trip_1242x840_1.jpg",
                    "middle": "http://www.ivydad.com/ivydad/image/book/131/Dentist_Trip_312x234_1.jpg",
                    "small": "http://www.ivydad.com/ivydad/image/book/131/Dentist_Trip_210x180_1.jpg"
                },
                "cat_id": "01",
                "cat_name": "英文绘本",
                "desc": "《Peppa Pig 6 books in 1》（精装合辑，6个故事集合在一本书中,140页左右）这6个故事分别是：《Dentist Trip》牙医之旅，《Peppa Goes Swimming》去游泳，《Nature Trail》天然路径，《School Bus Trip》校车之旅，《Peppa Plays Football》踢足球，《Peppa Goes Camping》去露营。",
                "is_free": "1",
                "recommend": "这套绘本故事温馨，非常适合孩子的行为引导。故事情节不复杂，但是却“润物细无声”地给孩子带来积极正面的影响，引导他们如何与家人和朋友相处，引导他们建立生活的好习惯，引导他们学会分享……",
                "share_url": "http://exploiter.ivydad.com:80/book/share/131",
                "stage_id": "8",
                "stage_name": "英文团购",
                "story": "粉红猪Peppa Pig的动画片2004年在在英国的FIVE 和NICKJR.电视台首播后，全球超过120个国家的电视频道也相继播映，说是“红遍全世界”那是一点不夸张的！Peppa Pig动画片是拿大奖拿到手软的超人气节目，曾获2005年法国Annecy国际动画展Cristal奖（最佳电视制作），意大利Cartoons on the Bay动画展Pulcinella奖（最佳幼儿影集）（年度最佳欧洲节目），英国学院奖（最佳学龄前动画奖）等等。",
                "tags": "【特别提示】英文绘本音频为随书赠送，《彩虹鱼系列》和《鼹鼠的故事》音频为对应的团购书籍赠送，请到“常春藤爸爸”公众号的有赞小店获取。\n\n国学音频正在内测，目前只开放了3首免费完整版，九月份可通过全新会员制度获得相应播放权限。",
                "type_id": "16",
                "type_name": "Peppa Pig"
            },
            {
                "audio_list": [
                    {
                        "audio_length": "97",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/137/My_Car_americanLyric_3.lrc",
                        "audio_lyric_version": "3",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「My Car」",
                        "audio_type": "american",
                        "audio_type_name": "美音",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/137/My_Car_americanVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    },
                    {
                        "audio_length": "95",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/137/My_Car_englishLyric_3.lrc",
                        "audio_lyric_version": "3",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「My Car」",
                        "audio_type": "english",
                        "audio_type_name": "英音",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/137/My_Car_englishVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    }
                ],
                "author": "Byron Barton",
                "available_play": "1",
                "book_id": "137",
                "book_name": "My Car",
                "book_pic_list": {
                    "large": "http://www.ivydad.com/ivydad/image/book/137/My_Car_1242x840_2.jpg",
                    "middle": "http://www.ivydad.com/ivydad/image/book/137/My_Car_312x234_2.jpg",
                    "small": "http://www.ivydad.com/ivydad/image/book/137/My_Car_210x180_2.jpg"
                },
                "cat_id": "01",
                "cat_name": "英文绘本",
                "desc": "这套Byron Barton经典交通工具最全套装内含八册可爱的纸板书，介绍了生活中所有常见的、不常见的交通工具。Byron Barton擅长运用粗线条勾勒出孩子们心中喜爱的动态物体，如汽车，飞机，列车，船，建筑器械等。",
                "is_free": "1",
                "recommend": "绘本画风简洁明了，大面积使用高纯度色块的设计能有效吸引孩子的注意力，而且有助于刺激孩子的视觉发展。小开本尺寸，硬纸板材质，耐翻不怕撕。语言简单，故事情节易于孩子理解的同时又能给孩子带来深远的影响，非常适合幼儿进行英语启蒙。",
                "share_url": "http://exploiter.ivydad.com:80/book/share/137",
                "stage_id": "8",
                "stage_name": "英文团购",
                "story": "Byron Barton，生于1930年，是美国最受欢迎的儿童书作家及插画家之一。他偏好用粗黑的线条、鲜艳的颜色和独特的图形来描绘主题，并且他的故事简单，创意十足，对幼儿具有启发性。他创作的交通工具系列的作品（《Trains》，《Planes》，《Boats》，《Trucks》）都十分受小孩子们喜欢。",
                "tags": "【特别提示】英文绘本音频为随书赠送，《彩虹鱼系列》和《鼹鼠的故事》音频为对应的团购书籍赠送，请到“常春藤爸爸”公众号的有赞小店获取。\n\n国学音频正在内测，目前只开放了3首免费完整版，九月份可通过全新会员制度获得相应播放权限。",
                "type_id": "17",
                "type_name": "交通工具"
            },
            {
                "audio_list": [
                    {
                        "audio_length": "127",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/152/The_Ugly_Duckling_americanLyric_1.lrc",
                        "audio_lyric_version": "1",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「The Ugly Duckling」",
                        "audio_type": "american",
                        "audio_type_name": "美音",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/152/The_Ugly_Duckling_americanVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    },
                    {
                        "audio_length": "140",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/152/The_Ugly_Duckling_englishLyric_1.lrc",
                        "audio_lyric_version": "1",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「The Ugly Duckling」",
                        "audio_type": "english",
                        "audio_type_name": "英音",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/152/The_Ugly_Duckling_englishVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    }
                ],
                "author": "Ladybird Books",
                "available_play": "1",
                "book_id": "152",
                "book_name": "The Ugly Duckling",
                "book_pic_list": {
                    "large": "http://www.ivydad.com/ivydad/image/book/152/The_Ugly_Duckling_1242x840_1.jpg",
                    "middle": "http://www.ivydad.com/ivydad/image/book/152/The_Ugly_Duckling_312x234_1.jpg",
                    "small": "http://www.ivydad.com/ivydad/image/book/152/The_Ugly_Duckling_210x180_1.jpg"
                },
                "cat_id": "01",
                "cat_name": "英文绘本",
                "desc": "成系列的分级读物，强调的是通过系统性的难度分级，和循序渐进的语言接触，让孩子逐步获得自主阅读的能力。《Read it yourself with ladybird》是系列，共15本，有大家耳熟能详的安徒生爷爷的经典《丑小鸭》，也有来自各国的民间童话，比如挪威的《拔萝卜》等等。",
                "is_free": "1",
                "recommend": "耳熟能详的经典，既营养有趣，又能激发孩子读英文的信心；文本尽可能多的巧妙重复，高频词汇精心编排；多样的画风融合大师艺术，与文字高度紧密的结合；有阅读指南，也可以随意发挥。",
                "share_url": "http://exploiter.ivydad.com:80/book/share/152",
                "stage_id": "8",
                "stage_name": "英文团购",
                "story": "《Read it yourself with ladybird》，又一套出自百年“瓢虫”的绘本。这套书自首次出版以来已经30多年了，多次再版，至今都是瓢虫系列的畅销童书之一。难怪有英国亚马逊网友评论：“这套书从没过时一说！我曾经给我的孩子们读过，如今我的孩子也有了孩子，我又开始给他们读了，他们也很爱！”",
                "tags": "自主阅读",
                "type_id": "21",
                "type_name": "Read it yourself"
            },
            {
                "audio_list": [
                    {
                        "audio_length": "141",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/162/Topsy_and_Tim_At_the_Farm_americanLyric_1.lrc",
                        "audio_lyric_version": "1",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「Topsy and Tim At the Farm」",
                        "audio_type": "american",
                        "audio_type_name": "美音",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/162/Topsy_and_Tim_At_the_Farm_americanVoice_2.mp3",
                        "audio_version": "2",
                        "is_default": ""
                    },
                    {
                        "audio_length": "140",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/162/Topsy_and_Tim_At_the_Farm_englishLyric_1.lrc",
                        "audio_lyric_version": "1",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「Topsy and Tim At the Farm」",
                        "audio_type": "english",
                        "audio_type_name": "英音",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/162/Topsy_and_Tim_At_the_Farm_englishVoice_2.mp3",
                        "audio_version": "2",
                        "is_default": ""
                    }
                ],
                "author": "Ladybird Books",
                "available_play": "1",
                "book_id": "162",
                "book_name": "Topsy and Tim At the Farm",
                "book_pic_list": {
                    "large": "http://www.ivydad.com/ivydad/image/book/162/Topsy_and_Tim_At_the_Farm_1242x840_1.jpg",
                    "middle": "http://www.ivydad.com/ivydad/image/book/162/Topsy_and_Tim_At_the_Farm_312x234_1.jpg",
                    "small": "http://www.ivydad.com/ivydad/image/book/162/Topsy_and_Tim_At_the_Farm_210x180_1.jpg"
                },
                "cat_id": "01",
                "cat_name": "英文绘本",
                "desc": "成系列的分级读物，强调的是通过系统性的难度分级，和循序渐进的语言接触，让孩子逐步获得自主阅读的能力。《Read it yourself with ladybird》是系列，共15本，有大家耳熟能详的安徒生爷爷的经典《丑小鸭》，也有来自各国的民间童话，比如挪威的《拔萝卜》等等。",
                "is_free": "1",
                "recommend": "耳熟能详的经典，既营养有趣，又能激发孩子读英文的信心；文本尽可能多的巧妙重复，高频词汇精心编排；多样的画风融合大师艺术，与文字高度紧密的结合；有阅读指南，也可以随意发挥。",
                "share_url": "http://exploiter.ivydad.com:80/book/share/162",
                "stage_id": "8",
                "stage_name": "英文团购",
                "story": "《Read it yourself with ladybird》，又一套出自百年“瓢虫”的绘本。这套书自首次出版以来已经30多年了，多次再版，至今都是瓢虫系列的畅销童书之一。难怪有英国亚马逊网友评论：“这套书从没过时一说！我曾经给我的孩子们读过，如今我的孩子也有了孩子，我又开始给他们读了，他们也很爱！”",
                "tags": "自主阅读",
                "type_id": "21",
                "type_name": "Read it yourself"
            },
            {
                "audio_list": [
                    {
                        "audio_length": "106",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/65/%E4%B8%89%E5%AD%97%E7%BB%8F%EF%BC%88%E4%B8%80%EF%BC%89_readingLyric_9.lrc",
                        "audio_lyric_version": "9",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「三字经（一）」",
                        "audio_type": "reading",
                        "audio_type_name": "朗读",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/65/%E4%B8%89%E5%AD%97%E7%BB%8F%EF%BC%88%E4%B8%80%EF%BC%89_readingVoice_8.mp3",
                        "audio_version": "8",
                        "is_default": ""
                    },
                    {
                        "audio_length": "160",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/65/%E4%B8%89%E5%AD%97%E7%BB%8F%EF%BC%88%E4%B8%80%EF%BC%89_rhythmLyric_12.lrc",
                        "audio_lyric_version": "12",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「三字经（一）」",
                        "audio_type": "rhythm",
                        "audio_type_name": "律动",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/65/%E4%B8%89%E5%AD%97%E7%BB%8F%EF%BC%88%E4%B8%80%EF%BC%89_rhythmVoice_6.mp3",
                        "audio_version": "6",
                        "is_default": ""
                    },
                    {
                        "audio_length": "191",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/65/%E4%B8%89%E5%AD%97%E7%BB%8F%EF%BC%88%E4%B8%80%EF%BC%89_SleepingLyric_5.lrc",
                        "audio_lyric_version": "5",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「三字经（一）」",
                        "audio_type": "sleeping",
                        "audio_type_name": "哄睡",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/65/%E4%B8%89%E5%AD%97%E7%BB%8F%EF%BC%88%E4%B8%80%EF%BC%89_sleepingVoice_4.mp3",
                        "audio_version": "4",
                        "is_default": ""
                    }
                ],
                "author": "王应麟",
                "available_play": "1",
                "book_id": "65",
                "book_name": "三字经（一）",
                "book_pic_list": {
                    "large": "http://www.ivydad.com/ivydad/image/book/65/%E4%B8%89%E5%AD%97%E7%BB%8F_1242x840_2.jpg",
                    "middle": "http://www.ivydad.com/ivydad/image/book/65/%E4%B8%89%E5%AD%97%E7%BB%8F_312x234_2.jpg",
                    "small": "http://www.ivydad.com/ivydad/image/book/65/%E4%B8%89%E5%AD%97%E7%BB%8F_210x180_3.jpg"
                },
                "cat_id": "02",
                "cat_name": "国学",
                "desc": "《三字经》，是中国的传统启蒙教材。在中国古代经典当中，《三字经》是最浅显易懂的读本之一。《三字经》取材典故范，包括中国传统文化的文学、历史、哲学、天文地理、人伦义理、忠孝节义等等，而核心思想又包括了“仁，义，诚，敬，孝。”背诵《三字经》的同时，就了解了常识、传统国学及历史故事，以及故事内涵中的做人做事道理。",
                "is_free": "1",
                "recommend": "《三字经》在格式上，三字一句朗朗上口，因其文通俗、顺口、易记等特点，使其与《百家姓》、《千字文》并称为中国传统蒙学三大读物，合称“三百千”。  《三字经》与《百家姓》、《千字文》并称为三大国学启蒙读物。《三字经》是中华民族珍贵的文化遗产，它短小精悍、琅琅上口，千百年来，家喻户晓。其内容涵盖了历史、天文、地理、道德以及一些民间传说，所谓“熟读《三字经》，可知千古事”。基于历史原因，《三字经》难免含有一些精神糟粕、艺术瑕疵，但其独特的思想价值和文化魅力仍然为世人所公认，被历代中国人奉为经典并不断流传。",
                "share_url": "http://exploiter.ivydad.com:80/book/share/65",
                "stage_id": "1",
                "stage_name": "三字经",
                "story": "关于《三字经》的成书年代和作者历代说法不一，但是大多数学者的意见倾向于“宋儒王伯厚先生作《三字经》，以课家塾”。王应麟晚年教育本族子弟读书的时候，编写了一本融会经史子集的三字歌诀，据传就是《三字经》。\n一说是宋代人区适子。明末清初屈大均在“广东新语”卷十一中记载：“童蒙所诵三字经乃宋末区适子所撰。适子，顺德登洲人，字正叔，入元抗节不仕”，认为广东顺德人区适子才是《三字经》的真正作者。\n一说是明代人黎贞。清代邵晋涵诗：“读得贞黎三字训”，自注：“《三字经》，南海黎贞撰。”即以为明代黎贞撰。",
                "tags": "【特别提示】英文绘本音频为随书赠送，《彩虹鱼系列》和《鼹鼠的故事》音频为对应的团购书籍赠送，请到“常春藤爸爸”公众号的有赞小店获取。\n\n国学音频正在内测，目前只开放了3首免费完整版，九月份可通过全新会员制度获得相应播放权限。",
                "type_id": "10",
                "type_name": "三字经"
            },
            {
                "audio_list": [
                    {
                        "audio_length": "123",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/66/%E5%8D%83%E5%AD%97%E6%96%87%EF%BC%88%E4%B8%80%EF%BC%89_readingLyric_7.lrc",
                        "audio_lyric_version": "7",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「千字文（一）」",
                        "audio_type": "reading",
                        "audio_type_name": "朗读",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/66/%E5%8D%83%E5%AD%97%E6%96%87%EF%BC%88%E4%B8%80%EF%BC%89_readingVoice_4.mp3",
                        "audio_version": "4",
                        "is_default": ""
                    },
                    {
                        "audio_length": "96",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/66/%E5%8D%83%E5%AD%97%E6%96%87%EF%BC%88%E4%B8%80%EF%BC%89_rhythmLyric_9.lrc",
                        "audio_lyric_version": "9",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「千字文（一）」",
                        "audio_type": "rhythm",
                        "audio_type_name": "律动",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/66/%E5%8D%83%E5%AD%97%E6%96%87%EF%BC%88%E4%B8%80%EF%BC%89_rhythmVoice_5.mp3",
                        "audio_version": "5",
                        "is_default": ""
                    }
                ],
                "author": "周兴嗣",
                "available_play": "1",
                "book_id": "66",
                "book_name": "千字文（一）",
                "book_pic_list": {
                    "large": "http://www.ivydad.com/ivydad/image/book/66/%E5%8D%83%E5%AD%97%E6%96%87_1242x840_2.jpg",
                    "middle": "http://www.ivydad.com/ivydad/image/book/66/%E5%8D%83%E5%AD%97%E6%96%87_312x234_2.jpg",
                    "small": "http://www.ivydad.com/ivydad/image/book/66/%E5%8D%83%E5%AD%97%E6%96%87_210x180_3.jpg"
                },
                "cat_id": "02",
                "cat_name": "国学",
                "desc": "千字文，由南北朝时期梁朝散骑侍郎、给事中周兴嗣编纂、一千个汉字组成的韵文（在隋唐之前，不押韵、不对仗的文字，被称为“笔”，而非“文”）。梁武帝（502—549年）命人从王羲之书法作品中选取1000个不重复汉字，命员外散骑侍郎周兴嗣编纂成文。全文为四字句，对仗工整，条理清晰，文采斐然。《千字文》语句平白如话，易诵易记，并译有英文版、法文版、拉丁文版、意大利文版，是中国影响很大的儿童启蒙读物。\n中国大陆实行简化字、归并异体字后，其简体中文版本剩下九百九十余个相异汉字。",
                "is_free": "1",
                "recommend": "《千字文》在内容上熔各种知识于一炉，并通篇贯穿以统一的思想，脉络清晰，语言洗练。它的长处后来为《三字经》所吸取。",
                "share_url": "http://exploiter.ivydad.com:80/book/share/66",
                "stage_id": "2",
                "stage_name": "千字文",
                "story": "周兴嗣，字思纂，陈郡项人（现河南省沈丘县），卒于梁武帝普通二年。世居姑熟，博学善属文。武帝时，拜安成王国侍郎。帝每令兴嗣为文，如铜表铭、栅塘碣、檄魏文，次韵王义之书千字文。每奏，辄称善。官终给事中。兴嗣撰皇帝实录、皇德记、起居注、职仪等百余卷，又作有文集十卷，（《梁书》及《两唐书志》）传于世。但流传最广、最久远的，则是《千字文》。",
                "tags": "【特别提示】英文绘本音频为随书赠送，《彩虹鱼系列》和《鼹鼠的故事》音频为对应的团购书籍赠送，请到“常春藤爸爸”公众号的有赞小店获取。\n\n国学音频正在内测，目前只开放了3首免费完整版，九月份可通过全新会员制度获得相应播放权限。",
                "type_id": "11",
                "type_name": "千字文"
            },
            {
                "audio_list": [
                    {
                        "audio_length": "171",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/83/%E4%B8%9C_readingLyric_1.lrc",
                        "audio_lyric_version": "1",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「东」",
                        "audio_type": "reading",
                        "audio_type_name": "朗读",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/83/%E4%B8%9C_readingVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    },
                    {
                        "audio_length": "204",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/83/%E4%B8%9C_rhythmLyric_4.lrc",
                        "audio_lyric_version": "4",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「东」",
                        "audio_type": "rhythm",
                        "audio_type_name": "律动",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/83/%E4%B8%9C_rhythmVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    }
                ],
                "author": "车万育",
                "available_play": "1",
                "book_id": "83",
                "book_name": "东",
                "book_pic_list": {
                    "large": "http://www.ivydad.com/ivydad/image/book/83/%E4%B8%9C_1242x840_1.jpg",
                    "middle": "http://www.ivydad.com/ivydad/image/book/83/%E4%B8%9C_312x234_1.jpg",
                    "small": "http://www.ivydad.com/ivydad/image/book/83/%E4%B8%9C_210x180_1.jpg"
                },
                "cat_id": "02",
                "cat_name": "国学",
                "desc": "《声律启蒙》是清朝康熙年间进士车万育所著，内容甚是丰富，涉及天文地理、神话典故、时令文史、人伦世俗、宫室珍宝、山河景物、器用饮食、鸟兽花木等。",
                "is_free": "1",
                "recommend": "《声律启蒙》每韵三段，每段八个韵脚，有单字对、双子对、三字对、五字对、七字对、十一字对，句句对偶对仗，声调平仄交替，音韵协和优美，节奏明快上口。",
                "share_url": "http://exploiter.ivydad.com:80/book/share/83",
                "stage_id": "3",
                "stage_name": "声律启蒙 ",
                "story": "《声律启蒙》是学习汉语对偶技巧和音韵格律的最优秀的实用读物，流传甚广，经久不衰。",
                "tags": "【特别提示】英文绘本音频为随书赠送，《彩虹鱼系列》和《鼹鼠的故事》音频为对应的团购书籍赠送，请到“常春藤爸爸”公众号的有赞小店获取。\n\n国学音频正在内测，目前只开放了3首免费完整版，九月份可通过全新会员制度获得相应播放权限。",
                "type_id": "13",
                "type_name": "声律启蒙"
            },
            {
                "audio_list": [
                    {
                        "audio_length": "90",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/169/B-I-N-G-O_musicLyric_1.lrc",
                        "audio_lyric_version": "1",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「B-I-N-G-O」",
                        "audio_type": "music",
                        "audio_type_name": "歌曲",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/169/B-I-N-G-O_musicVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    }
                ],
                "author": "Twin Sisters",
                "available_play": "1",
                "book_id": "169",
                "book_name": "B-I-N-G-O",
                "book_pic_list": {
                    "large": "http://www.ivydad.com/ivydad/image/book/169/B-I-N-G-O_1242x840_1.jpg",
                    "middle": "http://www.ivydad.com/ivydad/image/book/169/B-I-N-G-O_312x234_1.jpg",
                    "small": "http://www.ivydad.com/ivydad/image/book/169/B-I-N-G-O_210x180_1.jpg"
                },
                "cat_id": "03",
                "cat_name": "",
                "desc": "跟着音乐旋律拍手摇摆，学习洗漱和穿衣的技能，玩有趣的游戏，学快乐的英语~美国最畅销教育音乐品牌Twin Sisters Production的经典儿歌，针对学龄前儿童精心打造。经Twin Sisters正式授权，在常青藤爸爸App上畅听。",
                "is_free": "1",
                "recommend": "Twin Sisters 用原创的儿歌，最标准的发音，新颖益智，地道有趣。在丰富的音乐中唱游，在歌声中潜移默化，培养第二外语的氛围，给孩子打下良好的英语基础。",
                "share_url": "http://exploiter.ivydad.com:80/book/share/169",
                "stage_id": "10",
                "stage_name": "儿歌",
                "story": "Twin Sisters Production是美国最权威的儿童音乐与教育节目製作公司，于1987年成立，在过往20多年内，不断製作与创造与儿童成长过程、学习和休憩有关的节目系列，最大特点是将音乐融入教育之中，达到寓教于乐的目的。内容主要包括学习语言、说话能力、数学、字母、科教、儿歌、休闲音乐等，是培养小朋友的学习兴趣修养和品行的最佳指南。",
                "tags": "",
                "type_id": "22",
                "type_name": "经典英文-免费"
            },
            {
                "audio_list": [
                    {
                        "audio_length": "158",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/171/Five_Little_Monkeys_Jumping_on_the_Bed_musicLyric_1.lrc",
                        "audio_lyric_version": "1",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「Five Little Monkeys Jumping on the Bed」",
                        "audio_type": "music",
                        "audio_type_name": "歌曲",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/171/Five_Little_Monkeys_Jumping_on_the_Bed_musicVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    }
                ],
                "author": "Twin Sisters",
                "available_play": "1",
                "book_id": "171",
                "book_name": "Five Little Monkeys Jumping on the Bed",
                "book_pic_list": {
                    "large": "http://www.ivydad.com/ivydad/image/book/171/Five_Little_Monkeys_Jumping_on_the_Bed_1242x840_1.jpg",
                    "middle": "http://www.ivydad.com/ivydad/image/book/171/Five_Little_Monkeys_Jumping_on_the_Bed_312x234_1.jpg",
                    "small": "http://www.ivydad.com/ivydad/image/book/171/Five_Little_Monkeys_Jumping_on_the_Bed_210x180_1.jpg"
                },
                "cat_id": "03",
                "cat_name": "",
                "desc": "跟着音乐旋律拍手摇摆，学习洗漱和穿衣的技能，玩有趣的游戏，学快乐的英语~美国最畅销教育音乐品牌Twin Sisters Production的经典儿歌，针对学龄前儿童精心打造。经Twin Sisters正式授权，在常青藤爸爸App上畅听。",
                "is_free": "1",
                "recommend": "Twin Sisters 用原创的儿歌，最标准的发音，新颖益智，地道有趣。在丰富的音乐中唱游，在歌声中潜移默化，培养第二外语的氛围，给孩子打下良好的英语基础。",
                "share_url": "http://exploiter.ivydad.com:80/book/share/171",
                "stage_id": "10",
                "stage_name": "儿歌",
                "story": "Twin Sisters Production是美国最权威的儿童音乐与教育节目製作公司，于1987年成立，在过往20多年内，不断製作与创造与儿童成长过程、学习和休憩有关的节目系列，最大特点是将音乐融入教育之中，达到寓教于乐的目的。内容主要包括学习语言、说话能力、数学、字母、科教、儿歌、休闲音乐等，是培养小朋友的学习兴趣修养和品行的最佳指南。",
                "tags": "",
                "type_id": "22",
                "type_name": "经典英文-免费"
            },
            {
                "audio_list": [
                    {
                        "audio_length": "137",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/172/Old_MacDonald_Had_a_Farm_musicLyric_1.lrc",
                        "audio_lyric_version": "1",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「Old MacDonald Had a Farm」",
                        "audio_type": "music",
                        "audio_type_name": "歌曲",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/172/Old_MacDonald_Had_a_Farm_musicVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    }
                ],
                "author": "Twin Sisters",
                "available_play": "1",
                "book_id": "172",
                "book_name": "Old MacDonald Had a Farm",
                "book_pic_list": {
                    "large": "http://www.ivydad.com/ivydad/image/book/172/Old_MacDonald_Had_a_Farm_1242x840_1.jpg",
                    "middle": "http://www.ivydad.com/ivydad/image/book/172/Old_MacDonald_Had_a_Farm_312x234_1.jpg",
                    "small": "http://www.ivydad.com/ivydad/image/book/172/Old_MacDonald_Had_a_Farm_210x180_1.jpg"
                },
                "cat_id": "03",
                "cat_name": "",
                "desc": "跟着音乐旋律拍手摇摆，学习洗漱和穿衣的技能，玩有趣的游戏，学快乐的英语~美国最畅销教育音乐品牌Twin Sisters Production的经典儿歌，针对学龄前儿童精心打造。经Twin Sisters正式授权，在常青藤爸爸App上畅听。",
                "is_free": "1",
                "recommend": "Twin Sisters 用原创的儿歌，最标准的发音，新颖益智，地道有趣。在丰富的音乐中唱游，在歌声中潜移默化，培养第二外语的氛围，给孩子打下良好的英语基础。",
                "share_url": "http://exploiter.ivydad.com:80/book/share/172",
                "stage_id": "10",
                "stage_name": "儿歌",
                "story": "Twin Sisters Production是美国最权威的儿童音乐与教育节目製作公司，于1987年成立，在过往20多年内，不断製作与创造与儿童成长过程、学习和休憩有关的节目系列，最大特点是将音乐融入教育之中，达到寓教于乐的目的。内容主要包括学习语言、说话能力、数学、字母、科教、儿歌、休闲音乐等，是培养小朋友的学习兴趣修养和品行的最佳指南。",
                "tags": "",
                "type_id": "22",
                "type_name": "经典英文-免费"
            },
            {
                "audio_list": [
                    {
                        "audio_length": "120",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/175/The_Wheels_on_the_Bus_musicLyric_1.lrc",
                        "audio_lyric_version": "1",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「The Wheels on the Bus」",
                        "audio_type": "music",
                        "audio_type_name": "歌曲",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/175/The_Wheels_on_the_Bus_musicVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    }
                ],
                "author": "Twin Sisters",
                "available_play": "1",
                "book_id": "175",
                "book_name": "The Wheels on the Bus",
                "book_pic_list": {
                    "large": "http://www.ivydad.com/ivydad/image/book/175/The_Wheels_on_the_Bus_1242x840_1.jpg",
                    "middle": "http://www.ivydad.com/ivydad/image/book/175/The_Wheels_on_the_Bus_312x234_1.jpg",
                    "small": "http://www.ivydad.com/ivydad/image/book/175/The_Wheels_on_the_Bus_210x180_1.jpg"
                },
                "cat_id": "03",
                "cat_name": "",
                "desc": "跟着音乐旋律拍手摇摆，学习洗漱和穿衣的技能，玩有趣的游戏，学快乐的英语~美国最畅销教育音乐品牌Twin Sisters Production的经典儿歌，针对学龄前儿童精心打造。经Twin Sisters正式授权，在常青藤爸爸App上畅听。",
                "is_free": "1",
                "recommend": "Twin Sisters 用原创的儿歌，最标准的发音，新颖益智，地道有趣。在丰富的音乐中唱游，在歌声中潜移默化，培养第二外语的氛围，给孩子打下良好的英语基础。",
                "share_url": "http://exploiter.ivydad.com:80/book/share/175",
                "stage_id": "10",
                "stage_name": "儿歌",
                "story": "Twin Sisters Production是美国最权威的儿童音乐与教育节目製作公司，于1987年成立，在过往20多年内，不断製作与创造与儿童成长过程、学习和休憩有关的节目系列，最大特点是将音乐融入教育之中，达到寓教于乐的目的。内容主要包括学习语言、说话能力、数学、字母、科教、儿歌、休闲音乐等，是培养小朋友的学习兴趣修养和品行的最佳指南。",
                "tags": "",
                "type_id": "22",
                "type_name": "经典英文-免费"
            },
            {
                "audio_list": [
                    {
                        "audio_length": "36",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/183/Little_Boy_Blue_musicLyric_1.lrc",
                        "audio_lyric_version": "1",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「Little Boy Blue」",
                        "audio_type": "music",
                        "audio_type_name": "歌曲",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/183/Little_Boy_Blue_musicVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    }
                ],
                "author": "Twin Sisters",
                "available_play": "1",
                "book_id": "183",
                "book_name": "Little Boy Blue",
                "book_pic_list": {
                    "large": "http://www.ivydad.com/ivydad/image/book/183/Little_Boy_Blue_1242x840_1.jpg",
                    "middle": "http://www.ivydad.com/ivydad/image/book/183/Little_Boy_Blue_312x234_1.jpg",
                    "small": "http://www.ivydad.com/ivydad/image/book/183/Little_Boy_Blue_210x180_1.jpg"
                },
                "cat_id": "03",
                "cat_name": "",
                "desc": "跟着音乐旋律拍手摇摆，学习洗漱和穿衣的技能，玩有趣的游戏，学快乐的英语~美国最畅销教育音乐品牌Twin Sisters Production的经典儿歌，针对学龄前儿童精心打造。经Twin Sisters正式授权，在常青藤爸爸App上畅听。",
                "is_free": "1",
                "recommend": "Twin Sisters 用原创的儿歌，最标准的发音，新颖益智，地道有趣。在丰富的音乐中唱游，在歌声中潜移默化，培养第二外语的氛围，给孩子打下良好的英语基础。",
                "share_url": "http://exploiter.ivydad.com:80/book/share/183",
                "stage_id": "10",
                "stage_name": "儿歌",
                "story": "Twin Sisters Production是美国最权威的儿童音乐与教育节目製作公司，于1987年成立，在过往20多年内，不断製作与创造与儿童成长过程、学习和休憩有关的节目系列，最大特点是将音乐融入教育之中，达到寓教于乐的目的。内容主要包括学习语言、说话能力、数学、字母、科教、儿歌、休闲音乐等，是培养小朋友的学习兴趣修养和品行的最佳指南。",
                "tags": "",
                "type_id": "22",
                "type_name": "经典英文-免费"
            },
            {
                "audio_list": [
                    {
                        "audio_length": "18",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/184/Little_Miss_Muffet_musicLyric_1.lrc",
                        "audio_lyric_version": "1",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「Little Miss Muffet」",
                        "audio_type": "music",
                        "audio_type_name": "歌曲",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/184/Little_Miss_Muffet_musicVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    }
                ],
                "author": "Twin Sisters",
                "available_play": "1",
                "book_id": "184",
                "book_name": "Little Miss Muffet",
                "book_pic_list": {
                    "large": "http://www.ivydad.com/ivydad/image/book/184/Little_Miss_Muffet_1242x840_1.jpg",
                    "middle": "http://www.ivydad.com/ivydad/image/book/184/Little_Miss_Muffet_312x234_1.jpg",
                    "small": "http://www.ivydad.com/ivydad/image/book/184/Little_Miss_Muffet_210x180_1.jpg"
                },
                "cat_id": "03",
                "cat_name": "",
                "desc": "跟着音乐旋律拍手摇摆，学习洗漱和穿衣的技能，玩有趣的游戏，学快乐的英语~美国最畅销教育音乐品牌Twin Sisters Production的经典儿歌，针对学龄前儿童精心打造。经Twin Sisters正式授权，在常青藤爸爸App上畅听。",
                "is_free": "1",
                "recommend": "Twin Sisters 用原创的儿歌，最标准的发音，新颖益智，地道有趣。在丰富的音乐中唱游，在歌声中潜移默化，培养第二外语的氛围，给孩子打下良好的英语基础。",
                "share_url": "http://exploiter.ivydad.com:80/book/share/184",
                "stage_id": "10",
                "stage_name": "儿歌",
                "story": "Twin Sisters Production是美国最权威的儿童音乐与教育节目製作公司，于1987年成立，在过往20多年内，不断製作与创造与儿童成长过程、学习和休憩有关的节目系列，最大特点是将音乐融入教育之中，达到寓教于乐的目的。内容主要包括学习语言、说话能力、数学、字母、科教、儿歌、休闲音乐等，是培养小朋友的学习兴趣修养和品行的最佳指南。",
                "tags": "",
                "type_id": "22",
                "type_name": "经典英文-免费"
            },
            {
                "audio_list": [
                    {
                        "audio_length": "45",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/187/Pat_a_Cake_Pat_a_Cake_musicLyric_1.lrc",
                        "audio_lyric_version": "1",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「Pat a Cake Pat a Cake」",
                        "audio_type": "music",
                        "audio_type_name": "歌曲",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/187/Pat_a_Cake_Pat_a_Cake_musicVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    }
                ],
                "author": "Twin Sisters",
                "available_play": "1",
                "book_id": "187",
                "book_name": "Pat a Cake Pat a Cake",
                "book_pic_list": {
                    "large": "http://www.ivydad.com/ivydad/image/book/187/Pat_a_Cake_Pat_a_Cake_1242x840_1.jpg",
                    "middle": "http://www.ivydad.com/ivydad/image/book/187/Pat_a_Cake_Pat_a_Cake_312x234_1.jpg",
                    "small": "http://www.ivydad.com/ivydad/image/book/187/Pat_a_Cake_Pat_a_Cake_210x180_1.jpg"
                },
                "cat_id": "03",
                "cat_name": "",
                "desc": "跟着音乐旋律拍手摇摆，学习洗漱和穿衣的技能，玩有趣的游戏，学快乐的英语~美国最畅销教育音乐品牌Twin Sisters Production的经典儿歌，针对学龄前儿童精心打造。经Twin Sisters正式授权，在常青藤爸爸App上畅听。",
                "is_free": "1",
                "recommend": "Twin Sisters 用原创的儿歌，最标准的发音，新颖益智，地道有趣。在丰富的音乐中唱游，在歌声中潜移默化，培养第二外语的氛围，给孩子打下良好的英语基础。",
                "share_url": "http://exploiter.ivydad.com:80/book/share/187",
                "stage_id": "10",
                "stage_name": "儿歌",
                "story": "Twin Sisters Production是美国最权威的儿童音乐与教育节目製作公司，于1987年成立，在过往20多年内，不断製作与创造与儿童成长过程、学习和休憩有关的节目系列，最大特点是将音乐融入教育之中，达到寓教于乐的目的。内容主要包括学习语言、说话能力、数学、字母、科教、儿歌、休闲音乐等，是培养小朋友的学习兴趣修养和品行的最佳指南。",
                "tags": "",
                "type_id": "22",
                "type_name": "经典英文-免费"
            },
            {
                "audio_list": [
                    {
                        "audio_length": "115",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/190/The_ABC_Song_musicLyric_1.lrc",
                        "audio_lyric_version": "1",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「The ABC Song」",
                        "audio_type": "music",
                        "audio_type_name": "歌曲",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/190/The_ABC_Song_musicVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    }
                ],
                "author": "Twin Sisters",
                "available_play": "1",
                "book_id": "190",
                "book_name": "The ABC Song",
                "book_pic_list": {
                    "large": "http://www.ivydad.com/ivydad/image/book/190/The_ABC_Song_1242x840_2.jpg",
                    "middle": "http://www.ivydad.com/ivydad/image/book/190/The_ABC_Song_312x234_2.jpg",
                    "small": "http://www.ivydad.com/ivydad/image/book/190/The_ABC_Song_210x180_2.jpg"
                },
                "cat_id": "03",
                "cat_name": "",
                "desc": "跟着音乐旋律拍手摇摆，学习洗漱和穿衣的技能，玩有趣的游戏，学快乐的英语~美国最畅销教育音乐品牌Twin Sisters Production的经典儿歌，针对学龄前儿童精心打造。经Twin Sisters正式授权，在常青藤爸爸App上畅听。",
                "is_free": "1",
                "recommend": "Twin Sisters 用原创的儿歌，最标准的发音，新颖益智，地道有趣。在丰富的音乐中唱游，在歌声中潜移默化，培养第二外语的氛围，给孩子打下良好的英语基础。",
                "share_url": "http://exploiter.ivydad.com:80/book/share/190",
                "stage_id": "10",
                "stage_name": "儿歌",
                "story": "Twin Sisters Production是美国最权威的儿童音乐与教育节目製作公司，于1987年成立，在过往20多年内，不断製作与创造与儿童成长过程、学习和休憩有关的节目系列，最大特点是将音乐融入教育之中，达到寓教于乐的目的。内容主要包括学习语言、说话能力、数学、字母、科教、儿歌、休闲音乐等，是培养小朋友的学习兴趣修养和品行的最佳指南。",
                "tags": "",
                "type_id": "22",
                "type_name": "经典英文-免费"
            },
            {
                "audio_list": [
                    {
                        "audio_length": "48",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/193/This_Little_Pig_musicLyric_1.lrc",
                        "audio_lyric_version": "1",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「This Little Pig」",
                        "audio_type": "music",
                        "audio_type_name": "歌曲",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/193/This_Little_Pig_musicVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    }
                ],
                "author": "Twin Sisters",
                "available_play": "1",
                "book_id": "193",
                "book_name": "This Little Pig",
                "book_pic_list": {
                    "large": "http://www.ivydad.com/ivydad/image/book/193/This_Little_Pig_1242x840_1.jpg",
                    "middle": "http://www.ivydad.com/ivydad/image/book/193/This_Little_Pig_312x234_1.jpg",
                    "small": "http://www.ivydad.com/ivydad/image/book/193/This_Little_Pig_210x180_1.jpg"
                },
                "cat_id": "03",
                "cat_name": "",
                "desc": "跟着音乐旋律拍手摇摆，学习洗漱和穿衣的技能，玩有趣的游戏，学快乐的英语~美国最畅销教育音乐品牌Twin Sisters Production的经典儿歌，针对学龄前儿童精心打造。经Twin Sisters正式授权，在常青藤爸爸App上畅听。",
                "is_free": "1",
                "recommend": "Twin Sisters 用原创的儿歌，最标准的发音，新颖益智，地道有趣。在丰富的音乐中唱游，在歌声中潜移默化，培养第二外语的氛围，给孩子打下良好的英语基础。",
                "share_url": "http://exploiter.ivydad.com:80/book/share/193",
                "stage_id": "10",
                "stage_name": "儿歌",
                "story": "Twin Sisters Production是美国最权威的儿童音乐与教育节目製作公司，于1987年成立，在过往20多年内，不断製作与创造与儿童成长过程、学习和休憩有关的节目系列，最大特点是将音乐融入教育之中，达到寓教于乐的目的。内容主要包括学习语言、说话能力、数学、字母、科教、儿歌、休闲音乐等，是培养小朋友的学习兴趣修养和品行的最佳指南。",
                "tags": "",
                "type_id": "22",
                "type_name": "经典英文-免费"
            },
            {
                "audio_list": [
                    {
                        "audio_length": "194",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/197/Head%2C_Shoulders%2C_Knees_and_Toes_musicLyric_1.lrc",
                        "audio_lyric_version": "1",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「Head, Shoulders, Knees and Toes」",
                        "audio_type": "music",
                        "audio_type_name": "歌曲",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/197/Head%2C_Shoulders%2C_Knees_and_Toes_musicVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    }
                ],
                "author": "Twin Sisters",
                "available_play": "1",
                "book_id": "197",
                "book_name": "Head, Shoulders, Knees and Toes",
                "book_pic_list": {
                    "large": "http://www.ivydad.com/ivydad/image/book/197/Head%2C_Shoulders%2C_Knees_and_Toes_1242x840_1.jpg",
                    "middle": "http://www.ivydad.com/ivydad/image/book/197/Head%2C_Shoulders%2C_Knees_and_Toes_312x234_1.jpg",
                    "small": "http://www.ivydad.com/ivydad/image/book/197/Head%2C_Shoulders%2C_Knees_and_Toes_210x180_1.jpg"
                },
                "cat_id": "03",
                "cat_name": "",
                "desc": "跟着音乐旋律拍手摇摆，学习洗漱和穿衣的技能，玩有趣的游戏，学快乐的英语~美国最畅销教育音乐品牌Twin Sisters Production的经典儿歌，针对学龄前儿童精心打造。经Twin Sisters正式授权，在常青藤爸爸App上畅听。",
                "is_free": "1",
                "recommend": "Twin Sisters 用原创的儿歌，最标准的发音，新颖益智，地道有趣。在丰富的音乐中唱游，在歌声中潜移默化，培养第二外语的氛围，给孩子打下良好的英语基础。",
                "share_url": "http://exploiter.ivydad.com:80/book/share/197",
                "stage_id": "10",
                "stage_name": "儿歌",
                "story": "Twin Sisters Production是美国最权威的儿童音乐与教育节目製作公司，于1987年成立，在过往20多年内，不断製作与创造与儿童成长过程、学习和休憩有关的节目系列，最大特点是将音乐融入教育之中，达到寓教于乐的目的。内容主要包括学习语言、说话能力、数学、字母、科教、儿歌、休闲音乐等，是培养小朋友的学习兴趣修养和品行的最佳指南。",
                "tags": "",
                "type_id": "22",
                "type_name": "经典英文-免费"
            },
            {
                "audio_list": [
                    {
                        "audio_length": "139",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/198/Hush_Little_Baby_musicLyric_2.lrc",
                        "audio_lyric_version": "2",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「Hush Little Baby」",
                        "audio_type": "music",
                        "audio_type_name": "歌曲",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/198/Hush_Little_Baby_musicVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    }
                ],
                "author": "Twin Sisters",
                "available_play": "1",
                "book_id": "198",
                "book_name": "Hush Little Baby",
                "book_pic_list": {
                    "large": "http://www.ivydad.com/ivydad/image/book/198/Hush_Little_Baby_1242x840_1.jpg",
                    "middle": "http://www.ivydad.com/ivydad/image/book/198/Hush_Little_Baby_312x234_1.jpg",
                    "small": "http://www.ivydad.com/ivydad/image/book/198/Hush_Little_Baby_210x180_1.jpg"
                },
                "cat_id": "03",
                "cat_name": "",
                "desc": "跟着音乐旋律拍手摇摆，学习洗漱和穿衣的技能，玩有趣的游戏，学快乐的英语~美国最畅销教育音乐品牌Twin Sisters Production的经典儿歌，针对学龄前儿童精心打造。经Twin Sisters正式授权，在常青藤爸爸App上畅听。",
                "is_free": "1",
                "recommend": "Twin Sisters 用原创的儿歌，最标准的发音，新颖益智，地道有趣。在丰富的音乐中唱游，在歌声中潜移默化，培养第二外语的氛围，给孩子打下良好的英语基础。",
                "share_url": "http://exploiter.ivydad.com:80/book/share/198",
                "stage_id": "10",
                "stage_name": "儿歌",
                "story": "Twin Sisters Production是美国最权威的儿童音乐与教育节目製作公司，于1987年成立，在过往20多年内，不断製作与创造与儿童成长过程、学习和休憩有关的节目系列，最大特点是将音乐融入教育之中，达到寓教于乐的目的。内容主要包括学习语言、说话能力、数学、字母、科教、儿歌、休闲音乐等，是培养小朋友的学习兴趣修养和品行的最佳指南。",
                "tags": "",
                "type_id": "22",
                "type_name": "经典英文-免费"
            },
            {
                "audio_list": [
                    {
                        "audio_length": "177",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/200/Mary_Had_a_Little_Lamb_musicLyric_2.lrc",
                        "audio_lyric_version": "2",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「Mary Had a Little Lamb」",
                        "audio_type": "music",
                        "audio_type_name": "歌曲",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/200/Mary_Had_a_Little_Lamb_musicVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    }
                ],
                "author": "Twin Sisters",
                "available_play": "1",
                "book_id": "200",
                "book_name": "Mary Had a Little Lamb",
                "book_pic_list": {
                    "large": "http://www.ivydad.com/ivydad/image/book/200/Mary_Had_a_Little_Lamb_1242x840_1.jpg",
                    "middle": "http://www.ivydad.com/ivydad/image/book/200/Mary_Had_a_Little_Lamb_312x234_1.jpg",
                    "small": "http://www.ivydad.com/ivydad/image/book/200/Mary_Had_a_Little_Lamb_210x180_1.jpg"
                },
                "cat_id": "03",
                "cat_name": "",
                "desc": "跟着音乐旋律拍手摇摆，学习洗漱和穿衣的技能，玩有趣的游戏，学快乐的英语~美国最畅销教育音乐品牌Twin Sisters Production的经典儿歌，针对学龄前儿童精心打造。经Twin Sisters正式授权，在常青藤爸爸App上畅听。",
                "is_free": "1",
                "recommend": "Twin Sisters 用原创的儿歌，最标准的发音，新颖益智，地道有趣。在丰富的音乐中唱游，在歌声中潜移默化，培养第二外语的氛围，给孩子打下良好的英语基础。",
                "share_url": "http://exploiter.ivydad.com:80/book/share/200",
                "stage_id": "10",
                "stage_name": "儿歌",
                "story": "Twin Sisters Production是美国最权威的儿童音乐与教育节目製作公司，于1987年成立，在过往20多年内，不断製作与创造与儿童成长过程、学习和休憩有关的节目系列，最大特点是将音乐融入教育之中，达到寓教于乐的目的。内容主要包括学习语言、说话能力、数学、字母、科教、儿歌、休闲音乐等，是培养小朋友的学习兴趣修养和品行的最佳指南。",
                "tags": "",
                "type_id": "22",
                "type_name": "经典英文-免费"
            },
            {
                "audio_list": [
                    {
                        "audio_length": "59",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/201/Row_Row_Row_Your_Boat_musicLyric_1.lrc",
                        "audio_lyric_version": "1",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「Row Row Row Your Boat」",
                        "audio_type": "music",
                        "audio_type_name": "歌曲",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/201/Row_Row_Row_Your_Boat_musicVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    }
                ],
                "author": "Twin Sisters",
                "available_play": "1",
                "book_id": "201",
                "book_name": "Row Row Row Your Boat",
                "book_pic_list": {
                    "large": "http://www.ivydad.com/ivydad/image/book/201/Row_Row_Row_Your_Boat_1242x840_1.jpg",
                    "middle": "http://www.ivydad.com/ivydad/image/book/201/Row_Row_Row_Your_Boat_312x234_1.jpg",
                    "small": "http://www.ivydad.com/ivydad/image/book/201/Row_Row_Row_Your_Boat_210x180_1.jpg"
                },
                "cat_id": "03",
                "cat_name": "",
                "desc": "跟着音乐旋律拍手摇摆，学习洗漱和穿衣的技能，玩有趣的游戏，学快乐的英语~美国最畅销教育音乐品牌Twin Sisters Production的经典儿歌，针对学龄前儿童精心打造。经Twin Sisters正式授权，在常青藤爸爸App上畅听。",
                "is_free": "1",
                "recommend": "Twin Sisters 用原创的儿歌，最标准的发音，新颖益智，地道有趣。在丰富的音乐中唱游，在歌声中潜移默化，培养第二外语的氛围，给孩子打下良好的英语基础。",
                "share_url": "http://exploiter.ivydad.com:80/book/share/201",
                "stage_id": "10",
                "stage_name": "儿歌",
                "story": "Twin Sisters Production是美国最权威的儿童音乐与教育节目製作公司，于1987年成立，在过往20多年内，不断製作与创造与儿童成长过程、学习和休憩有关的节目系列，最大特点是将音乐融入教育之中，达到寓教于乐的目的。内容主要包括学习语言、说话能力、数学、字母、科教、儿歌、休闲音乐等，是培养小朋友的学习兴趣修养和品行的最佳指南。",
                "tags": "",
                "type_id": "22",
                "type_name": "经典英文-免费"
            },
            {
                "audio_list": [
                    {
                        "audio_length": "62",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/202/The_Muffin_Man_musicLyric_1.lrc",
                        "audio_lyric_version": "1",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「The Muffin Man」",
                        "audio_type": "music",
                        "audio_type_name": "歌曲",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/202/The_Muffin_Man_musicVoice_1.mp3",
                        "audio_version": "1",
                        "is_default": ""
                    }
                ],
                "author": "Twin Sisters",
                "available_play": "1",
                "book_id": "202",
                "book_name": "The Muffin Man",
                "book_pic_list": {
                    "large": "http://www.ivydad.com/ivydad/image/book/202/The_Muffin_Man_1242x840_1.jpg",
                    "middle": "http://www.ivydad.com/ivydad/image/book/202/The_Muffin_Man_312x234_1.jpg",
                    "small": "http://www.ivydad.com/ivydad/image/book/202/The_Muffin_Man_210x180_1.jpg"
                },
                "cat_id": "03",
                "cat_name": "",
                "desc": "跟着音乐旋律拍手摇摆，学习洗漱和穿衣的技能，玩有趣的游戏，学快乐的英语~美国最畅销教育音乐品牌Twin Sisters Production的经典儿歌，针对学龄前儿童精心打造。经Twin Sisters正式授权，在常青藤爸爸App上畅听。",
                "is_free": "1",
                "recommend": "Twin Sisters 用原创的儿歌，最标准的发音，新颖益智，地道有趣。在丰富的音乐中唱游，在歌声中潜移默化，培养第二外语的氛围，给孩子打下良好的英语基础。",
                "share_url": "http://exploiter.ivydad.com:80/book/share/202",
                "stage_id": "10",
                "stage_name": "儿歌",
                "story": "Twin Sisters Production是美国最权威的儿童音乐与教育节目製作公司，于1987年成立，在过往20多年内，不断製作与创造与儿童成长过程、学习和休憩有关的节目系列，最大特点是将音乐融入教育之中，达到寓教于乐的目的。内容主要包括学习语言、说话能力、数学、字母、科教、儿歌、休闲音乐等，是培养小朋友的学习兴趣修养和品行的最佳指南。",
                "tags": "",
                "type_id": "22",
                "type_name": "经典英文-免费"
            },
            {
                "audio_list": [
                    {
                        "audio_length": "452",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/103/%E9%BC%B9%E9%BC%A0%E5%92%8C%E5%B0%8F%E8%80%81%E9%BC%A0_musicLyric_2.lrc",
                        "audio_lyric_version": "2",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「鼹鼠和小老鼠」",
                        "audio_type": "american",
                        "audio_type_name": "美音",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/103/%E9%BC%B9%E9%BC%A0%E5%92%8C%E5%B0%8F%E8%80%81%E9%BC%A0_musicVoice_2.mp3",
                        "audio_version": "0",
                        "is_default": ""
                    }
                ],
                "author": "兹德内克·米勒",
                "available_play": "1",
                "book_id": "103",
                "book_name": "鼹鼠和小老鼠",
                "book_pic_list": {
                    "large": "http://www.ivydad.com/ivydad/image/book/103/%E9%BC%B9%E9%BC%A0%E5%92%8C%E5%B0%8F%E8%80%81%E9%BC%A0_1242x840_1.jpg",
                    "middle": "http://www.ivydad.com/ivydad/image/book/103/%E9%BC%B9%E9%BC%A0%E5%92%8C%E5%B0%8F%E8%80%81%E9%BC%A0_312x234_1.jpg",
                    "small": "http://www.ivydad.com/ivydad/image/book/103/%E9%BC%B9%E9%BC%A0%E5%92%8C%E5%B0%8F%E8%80%81%E9%BC%A0_210x180_1.jpg"
                },
                "cat_id": "04",
                "cat_name": "",
                "desc": "小老鼠邀请大家参加生日会，一场突如其来的大雨毁了小老鼠的家和生日会，小老鼠伤心极了。鼹鼠和伙伴们该如何帮助小老鼠呢？",
                "is_free": "1",
                "recommend": "“鼹鼠的故事（宝宝起步版）”系列共8册，包括《鼹鼠的春天》《鼹鼠的夏天》《鼹鼠的秋天》《鼹鼠的冬天》《鼹鼠和小老鼠》《鼹鼠和小兔子》《鼹鼠和小熊》《鼹鼠做裤子》。该系列主要描写一只小鼹鼠与伙伴们一起实现愿望的故事，故事简单，但耐人寻味。小鼹鼠永远乐观向上、豁达憨厚、乐于助人。小鼹鼠心地纯洁、善良，对于需要帮助的“人”，会毫不迟疑德伸出援助之手。为宝宝量身打造的阅读起步书，更是快乐幽默、童真意趣的经典作品。让孩子在互助互爱的温馨场景中体会生活的真善美。",
                "share_url": "http://exploiter.ivydad.com:80/book/share/103",
                "stage_id": "9",
                "stage_name": "中文故事",
                "story": "兹德内克·米勒是画家、平面艺术家，也是动画片制作家。他制作的影片在世界各地广受好评，并获得多项大奖。1956年的一天，他在散步时不小心被绊倒，掉进了一个鼹鼠土丘里。这位童心未泯的导演，突发奇想，萌生了创作出“小鼹鼠”动画形象。1957年，他的第一部影片《鼹鼠做裤子》问世，即获意大利威尼斯电影节银狮奖，并陆续在世界各地10多个国家获奖。",
                "tags": "【特别提示】英文绘本音频为随书赠送，《彩虹鱼系列》和《鼹鼠的故事》音频为对应的团购书籍赠送，请到“常春藤爸爸”公众号的有赞小店获取。\n\n国学音频正在内测，目前只开放了3首免费完整版，九月份可通过全新会员制度获得相应播放权限。",
                "type_id": "14",
                "type_name": "鼹鼠的故事"
            },
            {
                "audio_list": [
                    {
                        "audio_length": "558",
                        "audio_lyric_url": "http://www.ivydad.com/ivydad/voice/145/%E6%88%91%E6%98%AF%E5%BD%A9%E8%99%B9%E9%B1%BC_americanLyric_1.lrc",
                        "audio_lyric_version": "1",
                        "audio_share_content": "快和宝贝一起来听吧！",
                        "audio_share_title": "我和宝宝正在「常青藤爸爸」听绘本「我是彩虹鱼」",
                        "audio_type": "american",
                        "audio_type_name": "美音",
                        "audio_url": "http://www.ivydad.com/ivydad/voice/145/%E6%88%91%E6%98%AF%E5%BD%A9%E8%99%B9%E9%B1%BC_americanVoice_2.mp3",
                        "audio_version": "2",
                        "is_default": ""
                    }
                ],
                "author": "马克斯·菲斯特",
                "available_play": "1",
                "book_id": "145",
                "book_name": "我是彩虹鱼",
                "book_pic_list": {
                    "large": "http://www.ivydad.com/ivydad/image/book/145/%E6%88%91%E6%98%AF%E5%BD%A9%E8%99%B9%E9%B1%BC_1242x840_1.jpg",
                    "middle": "http://www.ivydad.com/ivydad/image/book/145/%E6%88%91%E6%98%AF%E5%BD%A9%E8%99%B9%E9%B1%BC_312x234_1.jpg",
                    "small": "http://www.ivydad.com/ivydad/image/book/145/%E6%88%91%E6%98%AF%E5%BD%A9%E8%99%B9%E9%B1%BC_210x180_1.jpg"
                },
                "cat_id": "04",
                "cat_name": "",
                "desc": "这条美丽的“彩虹鱼”来自瑞士，猛一看，他与一般的鱼并无差别，可你仔细看看，他身上有着闪光的七彩鳞片，因此得名“彩虹鱼”。“彩虹鱼系列”图画书至今已出版7册，包括《我是彩虹鱼》《条纹鱼得救了》《彩虹鱼和大鲸鱼》《我才不怕呢》《彩虹鱼迷路了》《深海大冒险》《快睡吧，彩虹鱼》。插画家马克斯·菲斯特仍然延续着“彩虹鱼系列”的创作，他希望不断为全世界的小读者塑造一个更温馨、更美丽、更欢乐的海底童话世界。",
                "is_free": "1",
                "recommend": "自诞生至今，二十多年过去了，这条美丽的“彩虹鱼”游遍了世界各地，受到了无数幼儿和成人的喜爱。故事中的彩虹鱼拥有孩子般的性格特点，他活泼、勇敢、乐群，同时也会犯各种各样小朋友容易犯的错误，但他在一次次的“试误”中学习、成长，逐渐学会分享、包容、沟通、互助和关爱，也锻炼了无所畏惧、勇于探索的精神。",
                "share_url": "http://exploiter.ivydad.com:80/book/share/145",
                "stage_id": "9",
                "stage_name": "中文故事",
                "story": "“彩虹鱼系列”曾荣获1993年意大利博洛尼亚国际儿童书展最佳童书奖、1993年英国凯特·格林纳威童书大奖、1993年法国图书馆最佳图书奖、1995年美国年度畅销童书奖、1996年美国童书协会儿童票选最佳图书奖、2010年美国纽约图书馆协会三苹奖等十多项国际大奖。目前已被译成36种语言，全球销量达到2000万册。",
                "tags": "【特别提示】英文绘本音频为随书赠送，《彩虹鱼系列》和《鼹鼠的故事》音频为对应的团购书籍赠送，请到“常春藤爸爸”公众号的有赞小店获取。\n\n国学音频正在内测，目前只开放了3首免费完整版，九月份可通过全新会员制度获得相应播放权限。",
                "type_id": "20",
                "type_name": "彩虹鱼系列"
            }
        ],
    }
};

