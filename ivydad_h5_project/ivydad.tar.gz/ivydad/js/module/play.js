/**
 * Created by liusome on 2016/10/26.
 */

$(function () {
    //获取参数book_id
    var book_id = getQuery("book_id");
    var voice = null;
    queryJsondata(audiojsondata,book_id,function(res){
        voice = res;
        //设置标题
        $("title").text(voice.book_name);
        // console.log(voice)
        $("#player_description").attr("content",voice.desc);
        laytpl(getTpl("tpl_pages")).render(voice, function(html){
            $("body").html(html);
            initPages();
            getVoiveInfo(voice.audio_list,0);
        });
    })
    $(document).on("click",".book-audio-type-container .book-audio-type",function(){
        var index = $(this).index();
        getVoiveInfo(voice.audio_list,index);
    })
    function initPages() {
        var ele = $('.page-swipe .wrap');
        var WinSize = {
            width:document.body.clientWidth,
            height:document.body.clientHeight
        }
        $(ele).css({
            width:WinSize.width + 'px'
        })
        var bullets = document.getElementById('position').getElementsByTagName('li');
        var sliderIndex = 1;
        var slider = Swipe(document.getElementById('slider'), {
            auto: false,
            startSlide:sliderIndex,
            continuous: true,
            callback: function(pos) {

                var i = bullets.length;
                while (i--) {
                    bullets[i].className = ' ';
                }
                bullets[pos].className = 'on';

            }
        });
        $('#position li').eq(sliderIndex).addClass('on').siblings().removeClass('on');
    }

    function getVoiveInfo(info,index) {
        $(".book-audio-type-container .book-audio-type").eq(index).addClass("on").siblings().removeClass("on");
        $("#jquery_jplayer_1").jPlayer("clearMedia");

        $("#jquery_jplayer_1").jPlayer({
            ready:function () {

            },
            ended:function (event) {
                if($(".jp-toggles .jp-repeat-off").is(":hidden")){
                    $(".book-image img").removeClass("rotate");
                }else{
                    $(".book-image img").addClass("rotate");
                }

            },
            play:function(){
            },
            timeupdate:function(event){
                // console.log(event.jPlayer.status.currentPercentAbsolute)
                //waitForLoad waitForPlay
                // console.log(event.jPlayer.status.waitForPlay)
                if(event.jPlayer.status.currentPercentAbsolute > 0){
                    $(".book-image img").addClass("rotate");
                    $(".jp-load").css("display","none");
                }else{
                    $(".jp-load").css("display","block");
                }
            },
            swfPath: "../libs/",
            supplied: "mp3",
            wmode: "window",
            smoothPlayBar: true,
            keyEnabled: true,
            smoothPlayBar: true,
            remainingDuration: false,
            toggleDuration: false
        });
        $("#jquery_jplayer_1").jPlayer("setMedia", {
            title: "",
            mp3: info[index].audio_url
        }).jPlayer("play");


        // $("#jquery_jplayer_1").jPlayer("play");
        // $(".book-image img").addClass("rotate");

        // $("#jquery_jplayer_1").jPlayer("timeupdate",function (event) {
        //     console.log(event)
            // $(".book-image img").removeClass("rotate");
        // });

        //本期不做，下期迭代
        // getLyric(info.audio_lyric_url)

    }
    //播放控制图片旋转
    $(document).on("click",".jp-controls li a.jp-play",function () {
        $(".book-image img").removeClass("rotatePause")
    })
    //暂停控制图片旋转
    $(document).on("click",".jp-controls li a.jp-pause",function () {
        $(".book-image img").addClass("rotatePause")
    })

    /****
     * 下载歌词
     ****/
    function getLyric(urlParam) {
        $.ajax({
            url:getRoot() + "jsonapi/api_lec_bookLrc",
            type:"POST",
            cache:false,
            async:false,
            data:{
                lrcUrl:urlParam,
                bookId:book_id,
            },
            success:function(data,textStatus){

                if (data.resultCode == "1") {
                    console.log(data.lrcInfo)
                } else {
                    console.log(data.message);
                }
            }
        });
    }

    var audioLrc;
    function voiceLryicScoll() {
        for (var i=0; i<audioLrc.length;i++) {
            if (audioParams.currentTime > audioLrc[i].time) {
                if (i==0) {
                    var prelrcId = (audioLrc.length-1);
                } else {
                    var prelrcId = (i-1);
                }
                var prelrcDivId = "audioLrc"+prelrcId;
                var preLrc = document.getElementById(prelrcDivId);
                preLrc.className="normal";
                var lrcDivId = "audioLrc"+i;
                var nowLrc = document.getElementById(lrcDivId);
                nowLrc.className="onload";
                lrcDiv = document.getElementById('book_info_voice_lrc');
                // 头两句不动
                if (i < 2) {
                    lrcDiv.scrollTop = 0 ;
                } else {
                    lrcDiv.scrollTop=lrcDiv.scrollTop + nowLrc.offsetHeight + 46;
                }
            }
        }
    }
})
