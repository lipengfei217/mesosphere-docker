/**
 * Created by liusome on 2016/11/07.
 */
//设置标题
$("title").text("常青藤爸爸");
var type_list = jsondata.data.type_list;
laytpl(getTpl("tpl_typeList")).render(type_list, function(html){
    $("body").html(html);
});
/**
 * 打开APP 图层 关闭按钮
 */
$(document).on("click",".fixed-header .right-btn .close img",function(e){
    var fixedHeader = $(this).parents(".fixed-header");
    fixedHeader.addClass("hide");
    $(".warp").css("padding-top",0);
    e.stopPropagation();
});
