/**
 * Created by liushuo on 2016/8/24.
 */

/**
 * 移动端root
 */
new function (){
    var _self = this;
    _self.width = 640;//设置默认最大宽度
    _self.fontSize = 100;//默认字体大小
    _self.widthProportion = function(){var p = (document.body&&document.body.clientWidth||document.getElementsByTagName("html")[0].offsetWidth)/_self.width;return p>1?1:p<0.5?0.5:p;};
    _self.changePage = function(){
        document.getElementsByTagName("html")[0].setAttribute("style","font-size:"+_self.widthProportion()*_self.fontSize+"px !important");
    }
    _self.changePage();
    window.addEventListener('resize',function(){
        _self.changePage();
    },false);
};

var ENVIRONMENT = "localhost"; //production 生产环境 test 测试环境 localhost
var STORAGE = window.localStorage;
var H5 = "H5";
//设置URL
function getRoot(){
    switch (ENVIRONMENT){
        case "production":
            return "http://exploiter.ivydad.com/";
        break;
        case "test":
            return "http://beta.exploiter.ivydad.com.cn/";
        break;
        case "localhost":
            return "/";
        break;
    }
    // return ENVIRONMENT == "production" ? "http://exploiter.ivydad.com/" : "http://beta.exploiter.ivydad.com.cn/";
}
//生成uuid
function createUUID() {
    var s = [];
    var hexDigits = "0123456789abcdef";
    for (var i = 0; i < 36; i++) {
        s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1);
    }
    s[14] = "4";  // bits 12-15 of the time_hi_and_version field to 0010
    s[19] = hexDigits.substr((s[19] & 0x3) | 0x8, 1);  // bits 6-7 of the clock_seq_hi_and_reserved to 01
    s[8] = s[13] = s[18] = s[23];

    var uuid = s.join("");
    setStorage("UUID",uuid)
    return uuid;

}
//获取手机型号
function getPhoneType() {
    var u = navigator.userAgent;
    if (u.indexOf('Android') > -1 || u.indexOf('Linux') > -1) {//Android设备
        return "Android";
    } else if (u.indexOf('iPhone') > -1 || u.indexOf('iPad') > -1) {//IOS设备
        return "IOS";
    } else if (u.indexOf('Windows Phone') > -1) {//Wp设备
        return "WP";
    }
}
//获取手机系统版本
function getOS(){
    //正则,忽略大小写
    var pattern_phone = new RegExp("iPhone","i");
    var pattern_android = new RegExp("android","i");
    var userAgent = navigator.userAgent.toLowerCase();
    var isAndroid = pattern_android.test(userAgent);
    var isIphone = pattern_phone.test(userAgent);
    var phoneType = null;
    if(isAndroid){
        var zh_cnIndex = userAgent.indexOf("-");
        var spaceIndex = userAgent.indexOf("build",zh_cnIndex+4);
        var fullResult = userAgent.substring(zh_cnIndex,spaceIndex);
        phoneType=fullResult.split(";")[1];
        phoneType = phoneType.split(" ")[2];
    }else if(isIphone){

        var ver = (navigator.appVersion).match(/OS (\d+)_(\d+)_?(\d+)?/);
        ver = parseInt(ver[1], 10);
        return ver;
        // phoneType = userAgent.match(/OS [5-9]_\d[_\d]* like Mac OS X/i)[0];
        // phoneType = phoneType.split(" ")[1];
        // phoneType = phoneType.replace("_",".");
    }else{
        phoneType = "unknow";
    }
    return phoneType;
}
/**
 * 获取存储val
 * @param item 存储key
 */
function getStorage(item) {
    return STORAGE.getItem(item);
}
/**
 * 离线存储
 * @param k key
 * @param v value
 */
function setStorage(k,v) {
    STORAGE.setItem(k,v);
}

/**
 * 公共参数
 * @param uuid 生成uuid
 * @param COMMONARGMENTS 公共参数
 */
// setStorage("UUID",uuid())

var uuid = null;
if(getStorage("UUID") == "undefined" || getStorage("UUID") == null){
    uuid = createUUID();
    setStorage("UUID",uuid)
}else {
    uuid = getStorage("UUID");
}
var COMMONARGMENTS = {
    device_id: uuid,
    phone_no_encryp:"",
    login_sys:H5+"_"+getPhoneType(),
    login_sys_version:getOS(),
    member_type:0,
    device_name:'',
    longitude:'',
    latitude:''
};

function geteval(res) {
    return '(' + res + ')'
}
/**
 * 过滤查询数据
 * @param json json数据
 * @param query 查询条件
 * @param fn callback
 */
function queryJsondata(json,query,fn) {
    var data = json.data.book_list;
    for (var i=0;i<data.length;i++){
        if(data[i].book_id == query){
            fn(data[i]);
            continue;
        }
    }
}
/**
 * 获取模板html
 * @param ele
 * @returns {string}
 */
function getTpl(ele){
    return document.getElementById(ele).innerHTML
}
/**
 * 获取url参数
 * @param name
 * @returns {null}
 */
function getQuery(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]);
    return null;
}
    
